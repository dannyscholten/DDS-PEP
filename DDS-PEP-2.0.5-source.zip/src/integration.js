/* Local integrated Personal Education Plan. Shared Build and Approval state. */
const INTEGRATED_VERSION='2.0.5';
// Live calendar movement: previews use the same scheduling validation as the final drop.
let calendarDrag=null,calendarDragSettling=false,calendarWarningContext=null;
function calendarDragFlexible(row){return isResearch(row)||['XM_0197','XM_0198'].includes(row.id);}
function calendarDragSchedule(row,start,year,seg){
 const current=schedule[row.id],next=current?clone(current):defaultSchedule(row,year);
 if(!calendarDragFlexible(row))return null;
 if(row.id==='XM_0197'){next.year=year;next[(seg?.label||'').includes('Theory')?'theoryPeriod':'practicePeriod']=monthPeriod(dateParts(start).month);}
 else{next.year=year;next.start=iso(start);next.awaitingStart=false;
  if(isResearch(row)&&current&&current.year!==year){next.leaveWeeks=row.id==='MAJOR'&&year===1?4:0;next.pauseWeeks=0;next.breakStart=row.id==='MAJOR'&&year===1?iso(date(1,7)):'';}
  if(row.id==='MAJOR'&&ms(next.breakStart)<start){next.leaveWeeks=0;next.breakStart='';}
 }
 next.proposed=false;next.awaitingPlacement=false;
 if(scheduleProblem(row,next))return null;
 // Calculate the real duration, segments and breaks without committing a preview.
 const previous=schedule[row.id];let t;try{schedule[row.id]=next;t=timing(row);}finally{if(previous)schedule[row.id]=previous;else delete schedule[row.id];}
 return t&&!t.awaitingStart?{row,next,t,start,year,segmentLabel:row.id==='XM_0197'?seg?.label:null}:null;
}
function calendarDragCandidates(row,seg){
 if(!calendarDragFlexible(row))return [];
 const plans=[];for(const year of [1,2])for(const month of [9,10,11,12,1,2,3,4,5,6]){const start=date(year,month);if(row.id==='XM_0197'&&periodBounds(year,monthPeriod(month))[0]!==start)continue;const plan=calendarDragSchedule(row,start,year,seg);if(plan)plans.push(plan);}return plans;
}
function calendarViews(){return [...document.querySelectorAll('#timeline .calendar:not(.small-year-calendar)')];}
function clearCalendarDropPreview(){document.querySelectorAll('.calendar-snap-line,.calendar-drop-preview').forEach(n=>n.remove());document.querySelectorAll('.calendar-drag-target').forEach(n=>n.classList.remove('calendar-drag-target'));}
function calendarViewDates(calendar){const year=Number(calendar.dataset.year);return {year,start:date(year,9),end:date(year+1,9)};}
function showCalendarSnapSpots(plans){for(const calendar of calendarViews()){calendar.classList.add('calendar-drag-target');const {year,start,end}=calendarViewDates(calendar);for(const plan of plans.filter(p=>p.year===year)){const n=el('div',undefined,'calendar-snap-line');n.style.left=(plan.start-start)/(end-start)*100+'%';n.style.top=calendar.querySelector('.axis').offsetHeight+'px';n.append(el('span',formatProjectDate(plan.start)));calendar.append(n);}}}
function showCalendarLanding(plan,categoryName,pointerY){
 document.querySelectorAll('.calendar-drop-preview').forEach(n=>n.remove());if(!plan)return;plan.previewRows=plan.previewRows||{};
 for(const calendar of calendarViews()){const {year,start,end}=calendarViewDates(calendar),lanes=[...calendar.querySelectorAll('.lane')],laneHeight=lanes[0]?.offsetHeight||72;
  if(!plan.previewRows[year]){const previous=schedule[plan.row.id];try{schedule[plan.row.id]=plan.next;plan.previewRows[year]=packedRows(start,end,year);}finally{if(previous)schedule[plan.row.id]=previous;else delete schedule[plan.row.id];}}
  const packed=plan.previewRows[year];for(const seg of plan.t.segments.filter(s=>!plan.segmentLabel||s.label===plan.segmentLabel)){const a=Math.max(start,seg.start),b=Math.min(end,seg.end);if(b<=a)continue;
   const index=packed.findIndex(lane=>lane.entries.some(entry=>entry.row.id===plan.row.id&&entry.seg.start===seg.start&&entry.seg.end===seg.end));if(index<0)continue;
   const n=style(el('div',undefined,'calendar-drop-preview'),category(plan.row));n.style.left=(a-start)/(end-start)*100+'%';n.style.width=(b-a)/(end-start)*100+'%';n.style.top=calendar.querySelector('.axis').offsetHeight+index*laneHeight+5+'px';n.append(el('span','Year '+plan.year+' - '+formatProjectDate(plan.start)));calendar.append(n);
  }
 }
}

function liveCalendarCandidate(point,d){
 const calendar=calendarViews().find(n=>{const r=n.getBoundingClientRect();return point.clientX>=r.left&&point.clientX<=r.right&&point.clientY>=r.top&&point.clientY<=r.bottom;});if(!calendar)return null;
 const {year,start,end}=calendarViewDates(calendar),r=calendar.getBoundingClientRect(),raw=start+(point.clientX-r.left)/r.width*(end-start)-d.anchorDays*DAY;
 return d.plans.filter(p=>p.year===year).sort((a,b)=>Math.abs(a.start-raw)-Math.abs(b.start-raw)||a.start-b.start)[0]||null;
}
function calendarDragReadout(d){const label=d.fixed?'Fixed teaching period - release to return':d.plan?'Release at Year '+d.plan.year+' - '+formatProjectDate(d.plan.start):'No permitted start here - release to return';d.readout.textContent=label;d.readout.style.left=Math.max(8,Math.min(innerWidth-285,d.lastX+14))+'px';d.readout.style.top=Math.max(8,Math.min(innerHeight-60,d.lastY+20))+'px';}
function moveLiveCalendarDrag(e){const d=calendarDrag;if(!d||d.pointer!==e.pointerId)return;d.lastX=e.clientX;d.lastY=e.clientY;if(!d.started&&Math.hypot(e.clientX-d.x,e.clientY-d.y)<5)return;
 if(!d.started){d.started=true;d.node.dataset.dragIgnore='true';cancelWarningTimer();warningBatch=null;d.plans=calendarDragCandidates(d.row,d.seg);d.fixed=!d.plans.length;const rect=d.node.getBoundingClientRect();d.rect=rect;const shell=el('div',undefined,'calendar calendar-drag-floating');Object.assign(shell.style,{left:rect.left+'px',top:rect.top+'px',width:rect.width+'px',height:rect.height+'px'});const copy=d.node.cloneNode(true);copy.classList.remove('selected');Object.assign(copy.style,{left:'0',top:'0',width:'100%',height:'100%'});copy.setAttribute('aria-hidden','true');copy.querySelectorAll('button,[tabindex]').forEach(n=>n.tabIndex=-1);shell.append(copy);document.body.append(shell);d.shell=shell;d.readout=el('div',undefined,'calendar-drag-readout');d.readout.setAttribute('aria-hidden','true');document.body.append(d.readout);d.node.classList.add('calendar-drag-source');document.body.classList.add('calendar-is-dragging');showCalendarSnapSpots(d.plans);requestAnimationFrame(scrollLiveCalendarDrag);}
 e.preventDefault();d.shell.style.transform='translate3d('+(e.clientX-d.x)+'px,'+(e.clientY-d.y)+'px,0)';d.plan=d.fixed?null:liveCalendarCandidate(e,d);showCalendarLanding(d.plan,category(d.row),e.clientY);calendarDragReadout(d);
}
function scrollLiveCalendarDrag(){const d=calendarDrag;if(!d?.started)return;const edge=60,speed=d.lastY>innerHeight-edge?Math.min(14,(d.lastY-innerHeight+edge)/3):d.lastY<edge?-Math.min(14,(edge-d.lastY)/3):0;if(speed){const before=scrollY;window.scrollBy(0,speed);if(scrollY!==before){d.plan=d.fixed?null:liveCalendarCandidate({clientX:d.lastX,clientY:d.lastY},d);showCalendarLanding(d.plan,category(d.row),d.lastY);calendarDragReadout(d);}}requestAnimationFrame(scrollLiveCalendarDrag);}
function finishLiveCalendarDrag(cancel=false){const d=calendarDrag;if(!d)return;calendarDrag=null;try{d.hit.releasePointerCapture(d.pointer);}catch(error){}if(!d.started)return;
 const plan=cancel?null:d.plan,changed=plan&&JSON.stringify(plan.next)!==JSON.stringify(schedule[d.row.id]);calendarDragSettling=true;d.shell.classList.add('calendar-drag-settling');let target=d.node.getBoundingClientRect();if(plan){const view=calendarViews().find(n=>Number(n.dataset.year)===plan.year),preview=view?.querySelector('.calendar-drop-preview');if(preview)target=preview.getBoundingClientRect();}
 d.shell.getBoundingClientRect();d.shell.style.transform='translate3d('+(target.left-d.rect.left)+'px,'+(target.top-d.rect.top)+'px,0)';d.readout.remove();let finished=false;
 const done=()=>{if(finished)return;finished=true;d.shell.remove();d.node.classList.remove('calendar-drag-source');clearCalendarDropPreview();document.body.classList.remove('calendar-is-dragging');calendarDragSettling=false;
  if(changed){selected=d.row.id;performCalendarDrop(d.row.id,()=>validChange(d.row,plan.next));}else{delete d.node.dataset.dragIgnore;}
 };
 d.shell.addEventListener('transitionend',done,{once:true});setTimeout(done,matchMedia('(prefers-reduced-motion: reduce)').matches?0:340);
}
function wireCalendarDrag(node,row,seg,t,start,end){node.draggable=false;node.addEventListener('dragstart',e=>{if(!node.closest('.small-year-calendar'))e.preventDefault();});node.addEventListener('click',e=>{if(node.dataset.dragIgnore){e.preventDefault();e.stopImmediatePropagation();}},true);const hit=node.querySelector('.block-hit');if(!hit)return;
 hit.addEventListener('pointerdown',e=>{if(e.button!==0||calendarDrag||calendarDragSettling||tourRunning||node.closest('.small-year-calendar')||sourceMap[row.id]?.sourceType==='marker')return;const rect=node.getBoundingClientRect(),view=node.closest('.calendar').getBoundingClientRect(),a=Math.max(seg.start,start);calendarDrag={node,row,seg,t,hit,pointer:e.pointerId,x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY,started:false,anchorDays:(row.id==='XM_0197'?0:(a-t.start)/DAY)+(e.clientX-rect.left)/view.width*(end-start)/DAY};hit.setPointerCapture(e.pointerId);});
 hit.addEventListener('pointermove',moveLiveCalendarDrag);hit.addEventListener('pointerup',e=>{if(calendarDrag?.pointer===e.pointerId){if(calendarDrag.started)moveLiveCalendarDrag(e);finishLiveCalendarDrag();}});hit.addEventListener('pointercancel',()=>finishLiveCalendarDrag(true));hit.addEventListener('lostpointercapture',()=>{if(calendarDrag)finishLiveCalendarDrag(true);});
}

let catalogueCalendarDrag=null;
function beginCatalogueCalendarPreview(row,e){
 clearCalendarDropPreview();const plans=(isResearch(row)||row.id==='XM_0198')?calendarDragCandidates(row,null):[];
 catalogueCalendarDrag={row,plans,anchorPixels:Math.max(0,e.clientX-e.currentTarget.getBoundingClientRect().left)};showCalendarSnapSpots(plans);
}
function catalogueLanding(e,calendar){if(!catalogueCalendarDrag?.plans.length)return null;const {start,end}=calendarViewDates(calendar),width=calendar.getBoundingClientRect().width,d={...catalogueCalendarDrag,anchorDays:catalogueCalendarDrag.anchorPixels/width*(end-start)/DAY};return liveCalendarCandidate(e,d);}
function endCatalogueCalendarPreview(){catalogueCalendarDrag=null;clearCalendarDropPreview();}
async function performCalendarDrop(id,operation){calendarWarningContext={courseId:id,delay:1000};try{return await operation();}finally{calendarWarningContext=null;}}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&calendarDrag){e.preventDefault();finishLiveCalendarDrag(true);}});
addEventListener('resize',()=>{if(calendarDrag)finishLiveCalendarDrag(true);});

let activeStep='build',approvalStage=0,buildView='';
let approvalPreviouslyAvailable=false;
let integrating=false,knownPlacements=new Map();
function viewChosen(){return ['calendar','list'].includes(buildView);}
const A=window.ApprovalRules;
const approvalRoot=document.getElementById('approval-workflow');
const sectionNavigation=document.getElementById('section-navigation');
document.getElementById('navigation-help').onclick=()=>document.getElementById('navigation-help-dialog').showModal();
document.getElementById('navigation-help-close').onclick=()=>document.getElementById('navigation-help-dialog').close();
const escapeHTML=value=>String(value??'').replace(/\u2014/g,'-').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const approvalStages=['Personal details','Project and course details','Review and download'];
const clone=value=>JSON.parse(JSON.stringify(value));
let warningBaseline=null,warningModel=null,warningBatch=null,warningQueued=false,warningSuppressed=false;
let warningTimer=null,warningTimerGeneration=0;
const seenCourseWarningPopups=new Set((()=>{try{const saved=JSON.parse(sessionStorage.getItem('dds-pep-course-warning-popups')||'[]');return Array.isArray(saved)?saved.filter(id=>typeof id==='string'):[];}catch(error){return [];}})());
function saveCourseWarningPopups(){try{sessionStorage.setItem('dds-pep-course-warning-popups',JSON.stringify([...seenCourseWarningPopups]));}catch(error){}}
function resetCourseWarningPopups(){acknowledgedPlanningWarnings.clear();savePlanningWarningAcknowledgements();seenCourseWarningPopups.clear();saveCourseWarningPopups();}
function cancelWarningTimer(){if(warningTimer!==null)clearTimeout(warningTimer);warningTimer=null;warningQueued=false;warningTimerGeneration++;}
function scheduleWarningPopup(delay){cancelWarningTimer();const generation=warningTimerGeneration;warningQueued=true;warningTimer=setTimeout(()=>{if(generation!==warningTimerGeneration)return;warningTimer=null;showActionWarnings();},delay);}
function changedWarningCourses(before,after){const a=JSON.parse(before),b=JSON.parse(after),ids=new Set([...Object.keys(a.schedule||{}),...Object.keys(b.schedule||{}),...(a.p.extracurricular||[]),...(b.p.extracurricular||[])]);return [...ids].filter(id=>JSON.stringify(a.schedule?.[id])!==JSON.stringify(b.schedule?.[id])||(a.p.extracurricular||[]).includes(id)!==(b.p.extracurricular||[]).includes(id));}
function processIcon(kind){const paths={build:'<path d="m14 10-9 10-3-3 10-9M10 4l4-2 7 7-3 3-7-7-1-1ZM18 6l2-2"/>',calendar:'<path d="M4 5h16v15H4zM4 10h16M9 10v10M15 10v10M8 3v4M16 3v4"/>',approval:'<path d="M7 3h10v4H7zM7 5H5v16h14V5h-2M8 13l3 3 5-6"/>',list:'<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',person:'<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',projects:'<path d="M3 8h18v12H3zM8 8V4h8v4M3 13h18M10 13v3h4v-3"/>',review:'<path d="M5 3h10l4 4v14H5zM9 14l2 2 5-6"/>'};return '<svg class="action-icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+(paths[kind]||paths.build)+'</svg>';}
function updateStickyHeights(){const actions=document.querySelector('.head-actions'),timeline=document.querySelector('.workflow-steps');document.documentElement.style.setProperty('--actions-height',actions.getBoundingClientRect().height+'px');document.documentElement.style.setProperty('--toolbar-height',(actions.getBoundingClientRect().height+timeline.getBoundingClientRect().height)+'px');}
function updateSetupRequiredLabels(){
 const own=DATA.specializations[p.student.specialization],needsPath=!!own&&Object.keys(own.paths).length>0;
 const items=[{done:viewChosen(),label:'#build-view-title'},{done:!!document.getElementById('cohort').value,label:'label[for="cohort"]'},{done:!!own,label:'label[for="spec"]'},...(needsPath?[{done:!!own.paths[p.student.path],label:'label[for="path"]'}]:[]),{done:!!p.student.education,label:'label[for="education"]'},{done:disclaimerAcknowledged,label:'#planning-disclaimer .warning>strong'}];
 for(const control of document.querySelectorAll('.configuration select'))control.required=true;
 for(const badge of document.querySelectorAll('.setup-required-label'))badge.remove();
 for(const control of document.querySelectorAll('.setup-unanswered'))control.classList.remove('setup-unanswered');
 for(const item of items)if(!item.done){const label=document.querySelector(item.label);label?.append(el('span',' Required','setup-required-label'));const fieldId=label?.getAttribute('for'),control=fieldId?document.getElementById(fieldId):item.label==='#build-view-title'?document.getElementById('build-view-picker'):document.querySelector('#planning-disclaimer .acknowledgement');control?.classList.add('setup-unanswered');}

}
function renderProcessTimeline(){
 for(const [step,icon]of [['build','build'],['approval','approval']]){const node=document.querySelector('#step-'+step+' .process-node');if(node&&!node.children.length)node.innerHTML=processIcon(icon);}
 const toc=document.getElementById('process-sections');toc.hidden=activeStep!=='approval';document.getElementById('approval-step-hint').hidden=activeStep==='approval'||plannerResult().total>=120;document.getElementById('approval-step-hint').textContent='Unlocks with 120 EC or more';toc.replaceChildren();
 if(activeStep==='approval')for(const [i,label]of approvalStages.entries()){const li=el('li'),button=el('button',undefined,'process-section');button.type='button';button.dataset.approvalStage=i;button.setAttribute('aria-current',i===approvalStage?'step':'false');button.innerHTML=processIcon(['person','projects','review'][i]);button.append(el('span',(i+1)+'. '+label));button.onclick=()=>goApprovalStage(i);li.append(button);toc.append(li);}
 for(const [id,kind]of [['view-calendar','calendar'],['view-list','list']]){const button=document.getElementById(id);button.setAttribute('aria-pressed',String(buildView===(id==='view-calendar'?'calendar':'list')));if(!button.querySelector('svg'))button.insertAdjacentHTML('afterbegin',processIcon(kind));}
 const compact=document.getElementById('process-view-switch');compact.hidden=activeStep!=='build'||!viewChosen()||!configurationReady()||!(disclaimerAcknowledged||tourRunning);
 compact.querySelectorAll('[data-build-view]').forEach(b=>{b.setAttribute('aria-pressed',String(b.dataset.buildView===buildView));if(!b.querySelector('svg'))b.insertAdjacentHTML('afterbegin',processIcon(b.dataset.buildView==='calendar'?'calendar':'list'));});
 document.getElementById('build-view-picker').hidden=activeStep!=='build'||viewChosen()&&configurationReady()&&disclaimerAcknowledged;
 sectionNavigation.append(compact,toc);mountSectionNavigation();updateStickyHeights();
}
function mountSectionNavigation(){
 const ready=configurationReady()&&viewChosen()&&(disclaimerAcknowledged||tourRunning);
 sectionNavigation.hidden=!ready;sectionNavigation.dataset.step=activeStep;
 if(activeStep==='approval')approvalRoot.prepend(sectionNavigation);else if(mobileQuery.matches)document.querySelector('.centre').prepend(sectionNavigation);else palettePanel.prepend(sectionNavigation);
}
function timingLines(row){
 const s=schedule[row.id],t=timing(row);if(s?.awaitingPlacement)return {main:'Placement required',months:'Choose a year and start month'};if(!t||t.awaitingStart)return {main:'Placement required',months:'Choose a start month'};
 if(!isResearch(row)&&row.id!=='XM_0198'){const label=regularPeriodLabel(row),match=label.match(/\((.*)\)$/);return {main:'Year '+s.year+' - '+label.replace(/\s*\(.*\)$/,''),months:match?match[1]:''};}
 let a=t.start,b=t.end;
 if(row.registrationPart){const active=researchSegments(t),weight=day=>{const band=t.rateBands?.find(x=>x.start<=day&&x.end>day);return band?.rate??splitRate(day)*researchDays(s)/5;};let total=0;for(const seg of active)for(let day=seg.start;day<seg.end;day+=DAY)total+=weight(day);let credits=0,cut=t.end;outer:for(const seg of active)for(let day=seg.start;day<seg.end;day+=DAY){credits+=weight(day);if(credits>=total*18/48-1e-8){cut=Math.min(t.end,nearestMonthEnd(t.start,day+DAY));break outer;}}if(row.registrationPart===1)b=cut;else a=cut;}
 const parts=[];for(const year of [1,2,3]){const ps=workloadWindows(year).filter(w=>w.start<b&&w.end>a).map(w=>w.period).filter(Boolean);const summer=a<date(year+1,9)&&b>date(year,7);if(ps.length)parts.push('Year '+year+' - '+(ps.length===1?'Period '+ps[0]:'Periods '+ps[0]+'-'+ps.at(-1))+(summer?', Summer':''));else if(summer)parts.push('Year '+year+' - Summer');}
 return {main:parts.join(' / '),months:formatProjectDate(a)+(dateParts(a).year!==dateParts(b-1).year?' (Year '+dateParts(a).year+')':'')+' - '+formatProjectDate(b-1)+(dateParts(a).year!==dateParts(b-1).year?' (Year '+dateParts(b-1).year+')':'')};
}
function automaticCourseYear(row){
 const project=r=>isResearch(r)||r.id==='XM_0198';
 const candidates=[1,2].map(year=>{const candidate=defaultSchedule(row,year),a=ms(candidate.start),b=ms(candidate.end),others=rows().filter(r=>r.id!==row.id).map(r=>({row:r,t:timing(r)})).filter(x=>x.t&&!x.t.awaitingStart),points=[...new Set([a,b,...others.flatMap(x=>(project(x.row)?researchSegments(x.t):x.t.segments).flatMap(seg=>[Math.max(a,Math.min(b,seg.start)),Math.max(a,Math.min(b,seg.end))]))])].sort((x,y)=>x-y);let projectDays=0,overloadDays=0;
 for(let i=0;i<points.length-1;i++){const start=points[i],end=points[i+1];if(end<=start)continue;const active=others.filter(x=>(project(x.row)?researchSegments(x.t):x.t.segments).some(seg=>seg.start<=start&&seg.end>start));const courses=active.filter(x=>!project(x.row)&&!workloadExempt(x.row)).length+(workloadExempt(row)?0:1);projectDays+=(end-start)/DAY*active.filter(x=>project(x.row)).length;overloadDays+=(end-start)/DAY*Math.max(0,courses-2);}
 const windows=workloadWindows(year),weights=windows.map(w=>w.period?Math.max(0,Math.min(b,w.end)-Math.max(a,w.start))/(w.end-w.start)*w.weeks:0),totalWeight=weights.reduce((n,v)=>n+v,0);for(const [index,w]of windows.entries())if([3,6].includes(w.period)&&weights[index]>0){const load=periodWorkload(year)[index],ownEC=load.items.filter(item=>item.id===row.id&&!item.research).reduce((n,item)=>n+item.ec,0),projected=load.courseEC-ownEC+row.ec*weights[index]/totalWeight;if(projected>=12-1e-8)overloadDays+=(w.end-w.start)/DAY;}
 return {year,projectDays,overloadDays};});return candidates.sort((a,b)=>Number(a.projectDays>0)-Number(b.projectDays>0)||a.projectDays-b.projectDays||a.overloadDays-b.overloadDays||a.year-b.year)[0].year;
}

// Presentation-only acknowledgements: never alter warning evaluation or export eligibility.
let planningWarningBodyId=0;
const acknowledgedPlanningWarnings=new Set((()=>{try{const value=JSON.parse(sessionStorage.getItem('dds-pep-planning-warning-ack')||'[]');return Array.isArray(value)?value.filter(s=>typeof s==='string'):[];}catch(error){return [];}})());
function savePlanningWarningAcknowledgements(){try{sessionStorage.setItem('dds-pep-planning-warning-ack',JSON.stringify([...acknowledgedPlanningWarnings]));}catch(error){}}
function canAcknowledgePlanningWarning(w){return !String(w.key||'').startsWith('placement-')&&!w.approvalIssue&&['advisory','information'].includes(warningPanelTone(w));}
function setPlanningWarningCollapsed(card,collapsed){const key=card.dataset.planningWarningKey;if(!key)return;collapsed?acknowledgedPlanningWarnings.add(key):acknowledgedPlanningWarnings.delete(key);savePlanningWarningAcknowledgements();syncPlanningWarningCards(key,collapsed);}
function syncPlanningWarningCards(key,collapsed){for(const card of document.querySelectorAll('[data-planning-warning-key]')){if(card.dataset.planningWarningKey!==key)continue;card.classList.toggle('planning-warning-collapsed',collapsed);const body=card.querySelector('.warning-panel-body'),head=card.querySelector('.warning-panel-toggle');if(body)body.hidden=collapsed;if(head)head.setAttribute('aria-expanded',String(!collapsed));}}
function enablePlanningWarningAcknowledgement(card,w){if(!canAcknowledgePlanningWarning(w))return card;const key=warningIdentity(w),old=card.querySelector('.warning-panel-heading'),body=card.querySelector('.warning-panel-body');if(!old||!body)return card;card.dataset.planningWarningKey=key;const head=el('button',undefined,'warning-panel-heading warning-panel-toggle');head.type='button';while(old.firstChild)head.append(old.firstChild);old.replaceWith(head);body.id='planning-warning-body-'+(++planningWarningBodyId);head.setAttribute('aria-controls',body.id);head.setAttribute('aria-expanded',String(!acknowledgedPlanningWarnings.has(key)));head.addEventListener('click',()=>setPlanningWarningCollapsed(card,!body.hidden));const acknowledge=el('button','Acknowledge','planning-acknowledge');acknowledge.type='button';acknowledge.setAttribute('aria-label','Acknowledge '+w.title);acknowledge.addEventListener('click',()=>{setPlanningWarningCollapsed(card,true);head.focus({preventScroll:true});if(card.closest('#action-warning-dialog')&&warningBatch?.warnings.every(item=>acknowledgedPlanningWarnings.has(warningIdentity(item))))closeActionWarning('keep');});body.append(acknowledge);const collapsed=acknowledgedPlanningWarnings.has(key);card.classList.toggle('planning-warning-collapsed',collapsed);body.hidden=collapsed;return card;}

function styleWarningPanel(card,title,tone='advisory'){
 card.classList.add('warning-panel');card.dataset.warningTone=tone;
 const head=el('div',undefined,'warning-panel-heading'),icon=el('span',undefined,'warning-panel-icon');
 icon.setAttribute('aria-hidden','true');
 const paths=tone==='information'?'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>':tone==='requirement'?'<circle cx="12" cy="12" r="9"/><path d="M12 7v6m0 4h.01"/>':'<path d="m12 3 10 18H2L12 3Z M12 9v5m0 3h.01"/>';
 icon.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+paths+'</svg>';
 head.append(icon,el('strong',title,'warning-panel-title'),el('span',tone==='requirement'?'Action required':tone==='decision'?'Decision required':'Planning advice','warning-panel-status'));
 const body=el('div',undefined,'warning-panel-body');
 const existing=card.querySelector(':scope > strong');if(existing)existing.remove();
 while(card.firstChild)body.append(card.firstChild);card.append(head,body);return card;
}
function warningPanelTone(w){if(w.tone)return w.tone;if(/Admissions Board|Review required|Exception requested/i.test(w.title))return 'decision';if(/start required|periods required/i.test(w.title))return 'requirement';return w.informational?'information':'advisory';}
function placementWarnings(){return rows().filter(row=>hasFlexiblePlacement(row)&&schedule[row.id]?.proposed&&!(row.id==='XM_0197'&&incompleteDidactics())).map(row=>({id:row.id,key:'placement-'+row.id,informational:true,title:schedule[row.id].awaitingPlacement?'Placement required - '+row.name:'Proposed placement - '+row.name,text:schedule[row.id].awaitingPlacement?'No non-overlapping automatic placement was found. The component remains in your curriculum. Choose a year and start month, then review any warnings.':(schedule[row.id].placementFallback?'No clash-free placement was available. This project is shown from '+(schedule[row.id].year===1?'Period 5 in Year 1':'Period 1 in Year 2')+'. Review the overlap and workload warnings. ':'')+'Review '+timingDescription(row)+'. Confirm this placement or adjust the timing in Course details.'}));}
function resetActionWarnings(){cancelWarningTimer();warningBaseline=null;warningModel=null;warningBatch=null;}
function queueActionWarnings(ws){
 if(tourRunning||detailsEdit)return;const model=stateSnapshot(),current=new Set(ws.filter(w=>!w.informational&&!w.silent).map(warningIdentity));
 if(warningBaseline&&warningModel&&JSON.parse(warningModel).disclaimerAcknowledged&&JSON.parse(model).disclaimerAcknowledged&&!sameBuildData(model,warningModel)&&!warningSuppressed){
  const pending=warningBatch;cancelWarningTimer();warningBatch=null;
  const ids=calendarWarningContext?[calendarWarningContext.courseId]:changedWarningCourses(warningModel,model),courseIds=(ids.length?ids:[selected]).filter(Boolean),unseen=courseIds.filter(id=>!seenCourseWarningPopups.has(id));
  const retained=pending?.courseIds?.some(id=>unseen.includes(id))?new Set(pending.warnings.map(warningIdentity)):new Set();
  const added=ws.filter(w=>!w.informational&&!w.silent&&!acknowledgedPlanningWarnings.has(warningIdentity(w))&&(!warningBaseline.has(warningIdentity(w))||retained.has(warningIdentity(w))));
  if(added.length&&unseen.length){const delay=calendarWarningContext?.delay||0;warningBatch={warnings:added,before:undoStack.at(-1)||null,selected:calendarWarningContext?.courseId||selected,courseIds:unseen,notBefore:Date.now()+delay};scheduleWarningPopup(delay);}
 }
 warningBaseline=current;warningModel=model;
}
function isYellowTimingWarning(w){return w.title==='Research project and course overlap'||w.title.startsWith('Mind high workload');}
function addCalendarGuidance(container,items){
 container.querySelectorAll('.calendar-guidance').forEach(n=>n.remove());
 const timingRelated=items.some(w=>isYellowTimingWarning(w)||w.severity==='overlap'||/placement|summer|scheduling|periods required|extends beyond|part-time/i.test(w.title));
 if(buildView==='list'&&timingRelated){const note=el('p',undefined,'calendar-guidance');if(container.id==='all-warnings'){const link=el('a','calendar view');link.href='#timeline';link.onclick=e=>{e.preventDefault();buildView='calendar';setStep('build');document.getElementById('timeline').scrollIntoView({block:'start'});};note.append(document.createTextNode('Consult '),link,document.createTextNode(' to understand timing-related warnings, such as overlap or high workload, and make adjustments if needed.'));}else note.textContent='Consult calendar view to understand timing-related warnings, such as overlap or high workload, and make adjustments if needed.';container.prepend(note);} 
}
function removedPrinciplesInBatch(batch){
 if(!batch?.before)return false;
 const previous=JSON.parse(batch.before);
 return DATA.principles.some(id=>previous.schedule?.[id]&&!previous.excluded?.includes(id)&&excluded.has(id));
}
function prioritizeWarnings(items){
 const important=w=>w.title==='Research components overlap'||!!w.approvalIssue||/curriculum requirement|mandatory course removed|major research project required|admissions board approval needed/i.test(w.title);
 const yellow=w=>!!w.informational||w.title==='Summer agreement'||isYellowTimingWarning(w);
 return [...items].sort((a,b)=>Number(yellow(a))-Number(yellow(b))||Number(important(b))-Number(important(a)));
}
function showActionWarnings(){warningQueued=false;if(!warningBatch||tourRunning||detailsEdit)return;if(calendarDrag||calendarDragSettling){scheduleWarningPopup(100);return;}const remaining=(warningBatch.notBefore||0)-Date.now();if(remaining>0){scheduleWarningPopup(remaining);return;}if(warningBatch.courseIds?.every(id=>seenCourseWarningPopups.has(id))){warningBatch=null;return;}const currentIdentities=new Set(warnings().map(warningIdentity));warningBatch.warnings=warningBatch.warnings.filter(w=>currentIdentities.has(warningIdentity(w)));if(!warningBatch.warnings.length){warningBatch=null;return;}const occupied=[...document.querySelectorAll('dialog[open]')].find(d=>d.id!=='action-warning-dialog');if(occupied){occupied.addEventListener('close',()=>setTimeout(showActionWarnings,0),{once:true});return;}const dialog=document.getElementById('action-warning-dialog'),content=document.getElementById('action-warning-content');warningBatch.warnings=prioritizeWarnings(warningBatch.warnings);const adjust=document.getElementById('action-warning-adjust');adjust.textContent=removedPrinciplesInBatch(warningBatch)?'Revert':'Change settings';const onlySummer=warningBatch.warnings.every(w=>w.title==='Summer agreement'),onlyExcess=warningBatch.warnings.every(w=>w.approvalIssue==='over120');adjust.hidden=onlySummer||onlyExcess;const keep=document.getElementById('action-warning-keep');keep.hidden=onlySummer;keep.textContent=onlyExcess?'Acknowledge':'Continue anyway';content.replaceChildren(...warningBatch.warnings.map(w=>{const card=el('div',undefined,'warning'+(w.title==='Summer agreement'?' summer-notice':'')+(isYellowTimingWarning(w)?' timing-advisory':''));card.append(el('strong',w.title),el('span',w.text));return enablePlanningWarningAcknowledgement(styleWarningPanel(card,w.title,warningPanelTone(w)),w);}));addCalendarGuidance(content,warningBatch.warnings);if(!dialog.open){dialog.showModal();for(const id of warningBatch.courseIds||[])seenCourseWarningPopups.add(id);saveCourseWarningPopups();}}
function closeActionWarning(mode){const batch=warningBatch;warningBatch=null;document.getElementById('action-warning-dialog').close();if(!batch)return;
 if(mode==='cancel'&&batch.before){warningSuppressed=true;const navigation={activeStep,approvalStage,buildView};restoreState(batch.before);activeStep=navigation.activeStep;approvalStage=navigation.approvalStage;buildView=navigation.buildView;undoStack.pop();lastState=stateSnapshot();render();warningSuppressed=false;return;}
 if(mode==='adjust'){const warning=batch.warnings.find(w=>w.id===batch.selected||w.ids?.includes(batch.selected))||batch.warnings[0];resolvePlanningWarning(warning,batch.selected);}
}
function resolvePlanningWarning(w,preferred){
 if(w.approvalIssue){const issue=approvalEvaluation().issues.find(i=>i.id===w.approvalIssue);if(issue&&plannerResult().total>=120){setStep('approval');focusIssue(issue);return;}}
 const row=rows().find(r=>r.id===w.id)||rows().find(r=>r.id===preferred&&(w.ids?.includes(r.id)||w.id==='global'))||rows().find(r=>w.ids?.includes(r.id));if(row){selectCourse(row.id);return;}setStep('build');showWorkloadWarning(w.key||'');
}
function showOperationError(text){const dialog=document.getElementById('operation-error-dialog');document.getElementById('operation-error-text').textContent=text;if(!dialog.open)dialog.showModal();}

const extracurricularNotice='Extracurricular: included only for planning and workload. It will be listed on your diploma supplement and will not be included in the PEP submitted to the examination board for approval.';
function canMarkExtracurricular(row){
 if(!row||DATA.principles.includes(row.id)||['MAJOR','MAJOR_PART1','MAJOR_PART2','XM_0200'].includes(row.id)||R.requiredCodes(p).includes(row.id)||R.pathCodes(p).includes(row.id))return false;
 if(isEducation()&&p.constrained.includes(row.id))return false;
 return row.custom||['constrained','general','alpha','minor','literature','educationElective'].includes(category(row));
}
function isExtracurricular(row){return canMarkExtracurricular(row)&&Array.isArray(p.extracurricular)&&p.extracurricular.includes(row.id);}
function approvalRows(){return rows().filter(row=>!isExtracurricular(row));}
function renderExtracurricularSummary(){
 const chosen=rows().filter(isExtracurricular);let box=document.getElementById('extracurricular-summary');
 if(!box){box=el('details',undefined,'extracurricular-summary');box.id='extracurricular-summary';box.append(el('summary'),el('ul'));document.getElementById('checks').after(box);}
 box.hidden=!chosen.length||buildView==='calendar';box.querySelector('summary').textContent='Extracurricular courses and projects - '+R.round(chosen.reduce((n,r)=>n+r.ec,0))+' EC (outside the PEP)';box.querySelector('ul').replaceChildren(...chosen.map(row=>el('li',row.name+' - '+row.ec+' EC')));
}
function setExtracurricular(id,value){
 const row=rows().find(r=>r.id===id);if(!canMarkExtracurricular(row))return false;
 let ids=[id];if(['O_MWRLDBS_1','O_MWRLDBS_2'].includes(id))ids=rows().filter(r=>['O_MWRLDBS_1','O_MWRLDBS_2'].includes(r.id)&&canMarkExtracurricular(r)).map(r=>r.id);
 const chosen=new Set(p.extracurricular||[]);for(const key of ids)value?chosen.add(key):chosen.delete(key);p.extracurricular=[...chosen];render();return true;
}
function extracurricularBadge(){const badge=el('span',undefined,'extracurricular-icon');badge.title=extracurricularNotice;badge.setAttribute('role','img');badge.setAttribute('aria-label',extracurricularNotice);badge.innerHTML='<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4H4v16h16V10M14 4v6h6M18 2v6M15 5h6M8 14h8M8 17h5"/></svg>';return badge;}
function openExtracurricularSelection(){
 buildView='list';setStep('build');const timeline=document.getElementById('timeline');const note=el('div',undefined,'extracurricular-instruction');note.append(el('strong','Mark extracurricular electives'),el('p','Select an eligible elective below and enable Extracurricular in its course settings. Required courses, mandatory path courses and the major project must stay in the PEP.'));
 const candidates=rows().filter(canMarkExtracurricular);for(const row of candidates){const button=el('button',(isExtracurricular(row)?'Review ':'Mark ')+row.name);button.type='button';button.onclick=()=>selectCourse(row.id,'extracurricular');note.append(button);}if(!candidates.length)note.append(el('p','No eligible electives are currently selected. Add an eligible elective or request an exception for the excess credits.'));timeline.prepend(note);timeline.scrollIntoView({block:'start'});
}
function compositionFingerprint(){return JSON.stringify([p.student.cohort,p.student.specialization,p.student.path,p.student.education,p.student.institution,p.student.degree,p.principles,approvalRows().map(r=>[r.id,r.code,r.name,r.ec,r.level,r.category,r.institution,r.url]).sort((a,b)=>a[0].localeCompare(b[0])),Object.entries(schedule).map(([id,s])=>[id,s.year,s.start,s.end,s.daysPerWeek,s.fte,s.leaveWeeks,s.pauseWeeks,s.breakStart,s.theoryPeriod,s.practicePeriod]).sort((a,b)=>a[0].localeCompare(b[0])),customPeriods]);}
function approvalState(){
 const v=clone(p),ids=new Set(approvalRows().map(r=>r.id));delete v.extracurricular;
 v.student.cohort=2026;
 // Catalogue courses keep their published provider; unlisted courses store their own institution.
 v.courseDetails={};
 v.principles={override:true,required:DATA.principles.filter(id=>ids.has(id))};
 v.major={...A.fresh().major,...v.major,enabled:isEducation()?ids.has('XM_0200'):ids.has('MAJOR')};
 if(!isEducation())v.major.route=ids.has('MAJOR')?(schedule.MAJOR?.year===1?'split':'single'):'';
 v.minor.enabled=ids.has('MINOR');v.literature.enabled=ids.has('XM_0198');
 v.constrained=v.constrained.filter(id=>ids.has(id));v.electives=v.electives.filter(id=>ids.has(id));
 v.educationElectives=(v.educationElectives||[]).filter(id=>ids.has(id));v.custom=v.custom.filter(c=>ids.has(c.uid));
 v.builderExcluded=A.requiredCodes(v).filter(id=>!ids.has(id));
 v.coordinator=A.coordinatorName(v);return v;
}
function validateCurrentSchedule(ready=true){
 for(const row of rows()){
  const scheduleValue=schedule[row.id];if(!scheduleValue)throw Error('Missing schedule for '+row.name+'.');
  if(ready&&(scheduleValue.awaitingStart||scheduleValue.awaitingPlacement||row.id==='XM_0197'&&(!scheduleValue.theoryPeriod||!scheduleValue.practicePeriod)))throw Error('Complete the placement settings for '+row.name+'.');
  const problem=scheduleProblem(row,scheduleValue);if(problem)throw Error(row.name+': '+problem);
  if(!isEducation()&&!hasFlexiblePlacement(row)){const official=defaultSchedule(row,scheduleValue.year);if(scheduleValue.start!==official.start||scheduleValue.end!==official.end||scheduleValue.fte!==official.fte||scheduleValue.leaveWeeks||scheduleValue.pauseWeeks)throw Error('Use the cohort teaching periods for '+row.name+'.');}
  if(isResearch(row)&&scheduleValue.leaveWeeks+scheduleValue.pauseWeeks>0){const t=timing(row),start=ms(scheduleValue.breakStart),weeks=scheduleValue.leaveWeeks+scheduleValue.pauseWeeks;if(!Number.isFinite(start)||start<t.start||start+weeks*7*DAY>t.end||!t.breaks?.some(b=>Math.abs(b.start-start)<1))throw Error('The entire scheduled break must fit inside '+row.name+'.');}
 }
}
function approvalEvaluation(){
 const v=approvalState(),result=A.evaluate(v),builderTotal=R.round(approvalRows().reduce((n,r)=>n+r.ec,0));
 try{DDSValidation.validate(JSON.parse(stateSnapshot()),A);validateCurrentSchedule();}catch(error){const issue={id:'invalid_build_data',severity:'error',section:'review',message:error.message};result.errors.push(issue);result.issues.push(issue);result.canExport=false;}
 result.issues=result.issues.filter(i=>i.id!=='three_projects');result.warnings=result.warnings.filter(i=>i.id!=='three_projects');
 for(const [id,request]of Object.entries(p.exceptions||{})){if(request.reason&&request.selectionFingerprint!==compositionFingerprint()&&result.issues.some(i=>i.id===id&&i.requested)){const issue={id:'reconfirm_'+id,severity:'error',section:'review',exceptionable:true,exceptionId:id,message:'Your curriculum changed after this exception was requested. Review and save the justification again: '+id.replaceAll('_',' ')+'.'};result.issues.push(issue);result.errors.push(issue);result.canExport=false;}}
 if(result.total!==builderTotal){const issue={id:'composition_mismatch',severity:'error',section:'review',message:'The two steps do not have the same credit total. Return to Build and review your selection.'};result.issues.push(issue);result.errors.push(issue);result.canExport=false;}
 return result;
}
function buildApprovalIssues(){return approvalEvaluation().issues.filter(i=>!i.id.startsWith('student_')&&!['personal','projects'].includes(i.section)&&!['under120','principles_decision'].includes(i.id));}
function acknowledgeSummerPopup(id){if(!warningBatch)return;warningBatch.warnings=warningBatch.warnings.filter(w=>!(w.title==='Summer agreement'&&w.id===id));if(!warningBatch.warnings.length){warningBatch=null;document.getElementById('action-warning-dialog').close();}else showActionWarnings();}
function firstYearPlacementWarnings(){return rows().filter(row=>firstYearCourse(row)&&schedule[row.id]?.year===2).map(row=>({id:row.id,key:'year-one-in-year-two-'+row.id,title:'Course intended for Year 1 - '+row.name,text:'This course is intended to be followed in the first year, as other courses and the research project build on it.',tone:'advisory',silent:true}));}
function integratedWarnings(){
 const issues=buildApprovalIssues(),base=legacyWarnings().filter(w=>!(/^Unlisted course\b/i.test(w.title)&&issues.some(i=>i.id.endsWith('_review'))));
 const replaced=new Set(['programme-over-120']);
 return prioritizeWarnings([...placementWarnings(),...firstYearPlacementWarnings(),...base.filter(w=>!replaced.has(w.key)&&w.title!=='Mandatory course removed'),...issues.filter(i=>!base.some(w=>w.text===i.message)).map(i=>({id:'global',key:'approval-'+i.id,title:i.requested?'Exception request':i.id.endsWith('_review')?'Unlisted course':i.severity==='review'?'Curriculum decision':'Curriculum check',text:i.message,approvalIssue:i.id,tone:i.severity==='error'?'requirement':i.severity==='review'?'decision':'advisory'}))]);
}
function hasFlexiblePlacement(row){return isResearch(row)||['XM_0197','XM_0198'].includes(row.id);}
function placementSignature(s){return JSON.stringify([s.year,s.start,s.end,s.theoryPeriod,s.practicePeriod,s.daysPerWeek,s.leaveWeeks,s.breakStart,s.awaitingStart,s.awaitingPlacement]);}
function synchronizePlacements(){
 if(integrating)return;integrating=true;
 try{
  const ids=new Set(rows().map(r=>r.id));for(const id of knownPlacements.keys())if(!ids.has(id))knownPlacements.delete(id);
  for(const row of rows()){
   const s=schedule[row.id];if(!s)continue;if(!hasFlexiblePlacement(row)){s.proposed=false;schedule[row.id].awaitingPlacement=false;}const signature=placementSignature(s),old=knownPlacements.get(row.id);
   if(['MAJOR','MINOR'].includes(row.id)&&(s.awaitingPlacement||s.awaitingStart))proposePlacement(row,s.year);
   else if(s.proposed===undefined){s.proposed=hasFlexiblePlacement(row);if((isResearch(row)||row.id==='XM_0198')&&!s.awaitingStart)proposePlacement(row,s.year);}
   else if(old&&old!==signature)s.proposed=false;
   knownPlacements.set(row.id,placementSignature(schedule[row.id]));
  }
 }finally{integrating=false;}
}
function proposePlacement(row,year){
 const current=clone(schedule[row.id]),normalPeriods=DEC.researchComponents[row.id]?.allowedStartPeriodsByYear?.[year]||researchStartPeriods(row.id,year),months=row.id==='XM_0200'?[2,3,4]:[9,10,11,12,1,2,3,4,5,6].filter(m=>row.id==='XM_0198'||normalPeriods.includes(monthPeriod(m)));
 const others=rows().filter(r=>r.id!==row.id).map(r=>({row:r,t:timing(r)})).filter(x=>x.t&&!x.t.awaitingStart);
 let best=null;
 for(const m of months){const candidate={...current,start:iso(date(year,m)),year,awaitingStart:false,awaitingPlacement:false,placementFallback:false};if(scheduleProblem(row,candidate))continue;schedule[row.id]=candidate;timingCache.clear();const t=timing(row);if(!t)continue;if(row.id==='MINOR'&&year===1&&!candidate.leaveWeeks&&researchDays(candidate)===5&&t.end>date(2,9))continue;
  const active=isResearch(row)?researchSegments(t):t.segments;if(row.id==='XM_0198'&&t.end>date(year,7))continue;const clashes=others.filter(o=>isResearch(o.row)||o.row.id==='XM_0198').some(o=>active.some(a=>(isResearch(o.row)?researchSegments(o.t):o.t.segments).some(b=>a.start<b.end&&a.end>b.start)));const courseClash=others.filter(o=>!workloadExempt(o.row)).some(o=>active.some(a=>(isResearch(o.row)?researchSegments(o.t):o.t.segments).some(b=>a.start<b.end&&a.end>b.start)));if(clashes||row.id==='MINOR'&&courseClash)continue;let score=0;
  for(const other of others){if(workloadExempt(other.row))continue;const segs=isResearch(other.row)?researchSegments(other.t):other.t.segments;for(const a of active)for(const b of segs)score+=Math.max(0,Math.min(a.end,b.end)-Math.max(a.start,b.start))/DAY*(isResearch(other.row)||other.row.id==='XM_0198'?100:1);}
  score+=Math.max(0,t.end-baseEnd)/DAY*1000;
  for(const y of [1,2])for(const seg of active)score+=Math.max(0,Math.min(seg.end,date(y+1,9))-Math.max(seg.start,date(y,7)))/DAY*3;
  if(!best||score<best.score)best={score,s:clone(candidate)};
 }
 if(!best&&['MAJOR','MINOR'].includes(row.id)){
  const fallback={...current,year,start:iso(periodBounds(year,year===1?5:1)[0]),proposed:true,awaitingPlacement:false,awaitingStart:false,placementFallback:true};
  if(!scheduleProblem(row,fallback)){schedule[row.id]=fallback;timingCache.clear();return true;}
 }
 schedule[row.id]={...(best?.s||current),proposed:true,awaitingPlacement:!best};timingCache.clear();return !!best;
}
function timingDescription(row){const t=timing(row),s=schedule[row.id];if(!s||s.awaitingPlacement)return 'Placement required';if(t?.awaitingStart)return 'Start month required';if(row.id==='XM_0197'&&incompleteDidactics())return 'Choose teaching periods';if(!t)return 'Placement required';if(isResearch(row)||row.id==='XM_0198')return 'Year '+s.year+' - '+formatProjectDate(t.start)+' - '+formatProjectDate(t.end-1)+(dateParts(t.end-1).year!==s.year?' - Year '+dateParts(t.end-1).year:'');return 'Year '+s.year+' - '+regularPeriodLabel(row);}
function unifiedCourseList(approval=false){
 const wrap=el('div',undefined,'curriculum-list');
 for(const section of ['Compulsory components','Elective space']){
  const chosen=(approval?approvalRows():rows()).filter(r=>categorySection(category(r))===section);if(!chosen.length)continue;
  const group=el('section',undefined,'list-main-group');group.append(el('h3',section));
  for(const [cat,c]of sidebarCategories()){
   const items=chosen.filter(r=>category(r)===cat).flatMap(row=>row.id==='MAJOR'&&schedule.MAJOR?.year===1?[{...row,name:'Major Research Project DDS - Part I',code:'XM_0207',ec:18,registrationPart:1},{...row,name:'Major Research Project DDS - Part II',code:'to be announced',ec:30,registrationPart:2}]:[row]);if(!items.length)continue;
   const card=style(el('section',undefined,'list-category'),cat),title=el('div',undefined,'list-category-title');title.append(el('h4',c.label),el('span',R.round(items.filter(r=>!isExtracurricular(r)).reduce((n,r)=>n+r.ec,0))+' EC'+(!approval&&items.some(isExtracurricular)?' PEP + '+R.round(items.filter(isExtracurricular).reduce((n,r)=>n+r.ec,0))+' EC extracurricular':'')));card.append(title);
   const table=el('table',undefined,'curriculum-table'),head=el('thead'),hr=el('tr');for(const [text,cls]of [[['major','minor'].includes(cat)?'Project':'Course','course-name-column'],['Course code','code-column'],['Level','level-column'],['Credits','credits-column'],...(!approval?[['Year & period(s)','timing-column']]:[]),['Actions','row-actions']])hr.append(el('th',text,cls));head.append(hr);table.append(head);const body=el('tbody');
   for(const row of items){const tr=el('tr');tr.dataset.courseId=row.id;if(isExtracurricular(row)){tr.classList.add('extracurricular-pattern');tr.title=extracurricularNotice;}const name=el('td',undefined,'course-name-column'),button=el('button',row.name,'course-name-button');button.type='button';button.addEventListener('click',()=>approval?focusApprovalCourse(row):selectCourse(row.id));name.append(button);if(isExtracurricular(row)){const mark=el('small',undefined,'extracurricular-label');mark.append(extracurricularBadge(),el('span','Extracurricular'));name.append(mark);}if(approval){const key=isResearch(row)?row.id==='MINOR'?'minor':'major':row.id==='XM_0198'?'literature':null;if(key){const detail=p[key];name.append(el('small','Host: '+(detail.host||'Details required')+' - Topic: '+(detail.topicStatus==='unknown'?'Not yet known':detail.topic||'Details required')));}}tr.append(name,el('td',row.code,'code-column'),el('td',String(row.level??(row.id==='MINOR'?500:row.project?600:'-')),'level-column'),el('td',row.ec+' EC','credits-column'));
    if(!approval){const td=el('td',undefined,'timing-column');const detail=timingLines(row);td.append(el('span',detail.main,'allocation-line'),el('small',detail.months,'teaching-months')); if(hasFlexiblePlacement(row)&&schedule[row.id]?.proposed){const proposed=el('button','Needs review','proposed-badge');proposed.title='Automatic placement. Review and confirm or adjust it.';proposed.addEventListener('click',()=>selectCourse(row.id));td.append(proposed);}tr.append(td);}
    const actions=el('td',undefined,'row-actions'),edit=el('button',undefined,'list-edit');edit.type='button';edit.innerHTML=gearIcon();edit.setAttribute('aria-label',(approval?'Complete details for ':'Edit ')+row.name);edit.addEventListener('click',()=>selectCourse(row.id));actions.append(edit);if(!approval)actions.append(removeControl(row,'list-remove'));tr.append(actions);body.append(tr);
   }table.append(body);const scroll=el('div',undefined,'curriculum-table-scroll');scroll.append(table);card.append(scroll);group.append(card);
  }wrap.append(group);
 }if(!rows().length)wrap.append(el('p','Add courses and projects from the Course Catalog.','empty-year'));return wrap;
}
function renderTimeline(){
 const dest=document.getElementById('timeline');dest.replaceChildren();dest.classList.toggle('mobile-calendar',useSmallYearCalendar()&&buildView==='calendar');
 if(buildView==='list')dest.append(unifiedCourseList());else if(mobileQuery.matches)dest.append(calendarPanel(date(mobileYear,9),date(mobileYear+1,9),mobileYear));else dest.append(calendarPanel(baseStart,date(2,9),1),calendarPanel(date(2,9),baseEnd,2));
 document.querySelector('.year-controls').classList.toggle('hidden',buildView!=='calendar'||!mobileQuery.matches);
 for(const [id,value]of [['mobile-year-one',mobileYear===1],['mobile-year-two',mobileYear===2],['view-list',buildView==='list'],['view-calendar',buildView==='calendar']])document.getElementById(id).setAttribute('aria-pressed',String(value));
}
function render(){synchronizePlacements();renderBuilder();renderIntegrated();}
let categoryLegendExpanded=false;
function focusTaskHeading(){const target=document.getElementById(activeStep==='approval'?'approval-title':configurationReady()&&viewChosen()&&disclaimerAcknowledged?'build-title':'build-view-title');if(target){target.tabIndex=-1;target.focus({preventScroll:true});}}
function syncReviewNavigation(){
 document.getElementById('skip-task').textContent=activeStep==='approval'?'Skip to form':'Skip to planning';
 const legend=document.getElementById('category-legend');if(legend)legend.open=!mobileQuery.matches||categoryLegendExpanded;
 fitHeaderTitle();
}
function fitHeaderTitle(){const title=document.querySelector('.header h1');if(!title)return;const base=mobileQuery.matches?25:innerWidth<=1100?25:29;title.style.fontSize=base+'px';if(title.scrollWidth>title.clientWidth&&title.clientWidth>0)title.style.fontSize=Math.max(10,Math.floor(base*title.clientWidth/title.scrollWidth*.98*10)/10)+'px';}
function updateReviewStatus(){
 const wc=document.getElementById('warning-count');if(!configurationReady()||!viewChosen()||!disclaimerAcknowledged)return;
 const r=approvalEvaluation(),actions=r.errors.filter(i=>activeStep==='approval'||!i.id.startsWith('student_')&&!['personal','projects'].includes(i.section)),decisions=r.issues.filter(i=>i.severity==='review'),advice=approvalPlanningWarnings().filter(w=>!r.issues.some(i=>i.message===w.text));
 const label=actions.length+' action required - '+decisions.length+' decision required - '+advice.length+' planning advice';wc.textContent=label;wc.disabled=!(actions.length+decisions.length+advice.length);wc.dataset.clear=String(wc.disabled);wc.dataset.severity=actions.length?'error':decisions.length?'review':advice.length?'advice':'clear';wc.setAttribute('aria-label',label+'. Open details');wc.setAttribute('aria-live','polite');
}
function scrollProcessTop(){if(!tourRunning)scrollTo({top:0,behavior:'instant'});}
function setStep(step){if(step==='build')approvalEditAccess=false;if(step==='approval'&&plannerResult().total<120)return;activeStep=step;render();scrollProcessTop();focusTaskHeading();}
function goApprovalStage(index){approvalStage=Math.max(0,Math.min(2,index));activeStep='approval';renderApproval();renderProcessTimeline();scrollProcessTop();focusTaskHeading();}
function renderIntegrated(){
 const ready=configurationReady()&&viewChosen()&&(disclaimerAcknowledged||tourRunning),canEnter=ready&&plannerResult().total>=120;
 if(!canEnter&&activeStep==='approval'&&!approvalEditAccess)activeStep='build';
 renderSetupSummary();renderExtracurricularSummary();organizeCourseDetails();requestAnimationFrame(equalizeCourseTiles);addCalendarGuidance(document.getElementById('all-warnings'),warnings());renderProcessTimeline();updateSetupRequiredLabels();
 syncReviewNavigation();document.body.dataset.hasCourses=String(rows().length>0);document.body.dataset.step=activeStep;const reviewWarnings=warnings();document.getElementById('all-warnings-label').textContent=reviewWarnings.length?reviewWarnings.length+' item'+(reviewWarnings.length===1?'':'s')+' to review':'No issues to review';document.body.dataset.buildView=buildView;document.querySelector('.desktop-canvas-instruction').textContent=buildView==='list'?'Review your course selection and curriculum checks. Select a course or project for details.':'Drag courses to the canvas, or add them from the Course Catalog';document.querySelector('.mobile-canvas-instruction').textContent=buildView==='list'?'Review your curriculum. Use + Add courses & projects to add more.':'Tap + Add courses & projects, or a category below, to get started';
 const approve=document.getElementById('step-approval');approve.disabled=!canEnter;document.querySelector('.process-timeline').classList.toggle('approval-available',canEnter);approve.title=canEnter?'Complete details and review your PEP':'Add at least 120 EC in Build to continue';
 if(canEnter&&!approvalPreviouslyAvailable&&activeStep==='build'&&!tourRunning)approve.classList.add('approval-just-unlocked');
 if(!canEnter||activeStep==='approval'||tourRunning)approve.classList.remove('approval-just-unlocked');
 approvalPreviouslyAvailable=canEnter;
 for(const step of ['build','approval']){const b=document.getElementById('step-'+step);b.setAttribute('aria-current',activeStep===step?'step':'false');}
 main.classList.toggle('hidden',!ready||activeStep!=='build');document.querySelector('.configuration').classList.toggle('hidden',activeStep==='approval');document.querySelector('.setup-instructions').classList.toggle('hidden',configurationReady()||activeStep==='approval');
 approvalRoot.hidden=!ready||activeStep!=='approval';document.getElementById('browse-courses').classList.toggle('hidden',!ready||activeStep!=='build');
 renderForwardAction();
 if(activeStep==='approval')renderApproval();updateReviewStatus();
 const drawer=document.getElementById('details-drawer'),row=rows().find(r=>r.id===selected);drawer.querySelector('.placement-review')?.remove();
 
}
function organizeCourseDetails(){
 const root=document.getElementById('inspector'),row=rows().find(r=>r.id===selected);if(!row)return;
 if(removalProtected(row)&&!root.querySelector('.selected-heading .course-lock'))root.querySelector('.selected-heading')?.append(requiredCourseLock());
 const metadata=root.querySelector('.selected-code');if(row.id==='MAJOR'&&schedule.MAJOR?.year===1&&metadata?.firstElementChild)metadata.firstElementChild.textContent='Course code: XM_0207 (Part I); Part II: to be announced';if(metadata){metadata.classList.add('information-tiles');for(const part of metadata.children){part.classList.add('information-tile');const text=part.textContent,colon=text.indexOf(':');if(colon>=0){part.replaceChildren(el('span',text.slice(0,colon),'tile-label'),el('strong',text.slice(colon+1).trim(),'tile-value'));}if(row.custom&&(text.startsWith('Course code:')||text.startsWith('Number of credits:'))){const b=el('button',undefined,'tile-edit');b.type='button';b.innerHTML=gearIcon();b.setAttribute('aria-label','Edit unlisted course information');b.onclick=()=>openCustom(row.id);part.append(b);}}}
 if(metadata){const level=row.level??(row.id==='MINOR'?500:row.project?600:null),tile=el('div',undefined,'information-tile course-level-tile');tile.append(el('span','Level','tile-label'),el('strong',level==null?'Not specified':String(level),'tile-value'));metadata.append(tile);}
 if(isResearch(row)||row.id==='XM_0198')root.querySelector('.course-span')?.remove();
 if(canMarkExtracurricular(row)){const tile=el('div',undefined,'information-tile extracurricular-setting'),label=el('label'),input=el('input');input.type='checkbox';input.id='detail-extracurricular';input.checked=isExtracurricular(row);label.append(input,el('strong','Extracurricular'));tile.append(label,el('p','When selected, this course remains in your planning and workload checks and will be listed on your diploma supplement. Its credits do not count towards the 120 EC PEP, and it will not appear in the PEP approval PDF submitted to the examination board.','help'));input.onchange=()=>setExtracurricular(row.id,input.checked);metadata.after(tile);}
 root.querySelectorAll('.field').forEach(wrap=>{const control=wrap.querySelector(':scope > select,:scope > input,:scope > output'),label=wrap.querySelector(':scope > label');if(!control||!label||!label.textContent.trim())return;wrap.classList.add('information-tile');label.classList.add('tile-label');if(control.tagName==='OUTPUT'){control.classList.add('tile-value');return;}const value=el('span',control.tagName==='SELECT'?control.selectedOptions[0]?.textContent||'Choose...':control.value,'tile-value tile-summary');wrap.insertBefore(value,control);const b=el('button',undefined,'tile-edit');b.type='button';b.innerHTML=gearIcon();b.setAttribute('aria-label','Edit '+label.textContent);b.onclick=()=>{wrap.classList.toggle('tile-editing');if(wrap.classList.contains('tile-editing'))control.focus();requestAnimationFrame(equalizeCourseTiles);};const content=el('div',undefined,'tile-content');wrap.insertBefore(content,value);content.append(value,b);control.classList.add('tile-control');if(!control.value||wrap.classList.contains('missing-period'))wrap.classList.add('tile-editing');});
 if(row.id==='XM_0197'){
 const fields=root.querySelector('#detail-year')?.closest('.fields');
 if(fields){const grid=el('div',undefined,'didactics-setting-tiles');
 for(const id of ['detail-year','theory-period','practice-period']){const control=root.querySelector('#'+id);if(control)grid.append(control.closest('.field'));}
 fields.append(grid);}
 }
 const firstFields=root.querySelector('.fields');
 if((isResearch(row)||row.id==='XM_0198')&&firstFields){firstFields.classList.add('project-date-tiles');for(const note of [...firstFields.querySelectorAll(':scope > p.full')])firstFields.before(note);}
 const advanced=root.querySelector('.advanced-options');
 if(advanced&&isResearch(row)&&!isEducation()){
  const grid=el('div',undefined,'project-option-tiles project-summary-tiles'),days=root.querySelector('#detail-days'),leave=root.querySelector('#detail-leave');
  if(days)grid.append(days.closest('.field'));
  const tile=el('div',undefined,'information-tile research-leave-tile'),label=el('div','Scheduled break','tile-label');
  tile.append(label);const content=el('div',undefined,'tile-content'),current=schedule[row.id],t=timing(row),weeks=current.leaveWeeks+current.pauseWeeks;
  const breakDate=weeks&&t.breaks?.[0]?iso(t.breaks[0].start):null;
  content.append(el('span',weeks?weeks+' weeks in Year '+academicYearOf(breakDate)+', starting '+dayMonth(breakDate):'0 weeks','tile-value tile-summary'));
  const edit=el('button',undefined,'tile-edit');edit.type='button';edit.innerHTML=gearIcon();edit.setAttribute('aria-label','Edit scheduled break');edit.onclick=()=>openResearchLeave(row);content.append(edit);tile.append(content);grid.append(tile);
  const duration=el('div',undefined,'information-tile project-duration-tile'),head=el('div','Total duration','tile-label'),info=el('button','i','category-info days-info');info.type='button';info.setAttribute('aria-label','Information about total duration');info.onclick=()=>{document.getElementById('category-info-title').textContent='Total project duration';document.getElementById('category-info-body').textContent=projectDurationHelp(row);document.getElementById('category-info-dialog').showModal();};head.append(info);duration.append(head,el('strong',Math.ceil((t.end-t.start)/DAY/7)+' weeks','tile-value'));grid.append(duration);
  const hidden=el('div',undefined,'hidden legacy-research-controls');
  if(leave)hidden.append(leave.closest('.field'));
  for(const id of ['detail-break-year','detail-break']){const control=root.querySelector('#'+id);if(control)hidden.append(control.closest('.field'));}
  advanced.replaceWith(hidden);firstFields.after(grid);root.querySelector('.duration-box')?.remove();
 }
 if(isResearch(row)&&isEducation()){
 const t=timing(row),grid=el('div',undefined,'project-option-tiles project-summary-tiles');
 for(const [label,value]of [['Days per week','5'],['Scheduled break','0 weeks'],['Total duration',Math.ceil((t.end-t.start)/DAY/7)+' weeks']]){const tile=el('div',undefined,'information-tile'),head=el('div',label,'tile-label');if(label==='Total duration'){const info=el('button','i','category-info days-info');info.type='button';info.setAttribute('aria-label','Information about total duration');info.onclick=()=>{document.getElementById('category-info-title').textContent='Total project duration';document.getElementById('category-info-body').textContent=projectDurationHelp(row);document.getElementById('category-info-dialog').showModal();};head.append(info);}tile.append(head,el('strong',value,'tile-value'));grid.append(tile);}
 root.querySelector('.duration-box')?.remove();firstFields?.after(grid);
 }
 root.querySelectorAll('.course-span').forEach(n=>{n.classList.add('information-tile');n.querySelector('strong')?.classList.add('tile-label');n.querySelector('div')?.classList.add('tile-value');});const remove=document.getElementById('remove-course');if(remove&&!remove.querySelector('svg')){remove.prepend(document.createElement('span'));remove.firstChild.innerHTML='<svg class="action-icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="m6 6 12 12M18 6 6 18"/></svg>';}
}
function projectDurationHelp(row){if(isEducation())return 'This Education research project lasts 20 weeks at 5 days per week. Leave and part-time adjustments are not available for this fixed 30 EC project. The total duration runs from Project start to Project end.';return 'Total duration is the time between Project start and Project end, rounded up to whole weeks. It is based on the selected days per week and any scheduled break, including a summer holiday. Five days per week is standard. A schedule of 3–5 days per week requires agreement with your supervisors; fewer days extend the project. Leave extends the planned project end date. The full-time reference is '+R.round(row.ec/1.5)+' weeks at 1.5 EC per week; the calendar calculation also uses teaching-period workload and month boundaries. A major project starting in Year 1 includes 4 weeks of summer leave by default. Minor projects and Year 2 starts have no automatic leave. You may plan 0–8 whole weeks, subject to agreement with your supervisors.';}
function researchLeaveYears(row){const t=timing(row),first=academicYearOf(iso(t.start)),last=academicYearOf(iso(t.end-1));return Array.from({length:last-first+1},(_,i)=>first+i);}
function researchLeaveProposal(row,rawWeeks,rawYear,relative){
 const weeks=Number(rawWeeks),year=Number(rawYear),years=researchLeaveYears(row);
 if(String(rawWeeks).trim()===''||!Number.isInteger(weeks)||weeks<0||weeks>8)return {error:'Enter 0–8 whole weeks of scheduled break.'};
 if(!years.includes(year))return {error:'Choose an academic year covered by this project.'};
 const value=parseRelative(relative,year);
 if(weeks&&!value)return {error:'Enter a valid start date as DD-MM in the selected academic year.'};
 const updates={leaveWeeks:weeks,pauseWeeks:0,breakStart:weeks?value:''},next={...schedule[row.id],...updates};
 const problem=scheduleProblem(row,next);if(problem)return {error:problem};
 if(weeks){
  const t=alignFlexibleTiming(splitTiming(row,ms(next.start),next)),start=ms(value),end=start+weeks*7*DAY;
  if(start<t.start||end>t.end)return {error:'The entire scheduled break must fit between Project start and Project end.'};
  const actual=t.breaks?.[0];
  if(!actual||Math.abs(actual.start-start)>1)return {error:'Choose a leave start before the project work is completed, within Project start and Project end.'};
 }
 return {updates};
}
function openResearchLeave(row){
 if(!row||!isResearch(row)||isEducation())return;
 let dialog=document.getElementById('research-leave-dialog');
 if(!dialog){dialog=el('dialog',undefined,'custom-dialog research-leave-dialog');dialog.id='research-leave-dialog';dialog.setAttribute('aria-labelledby','research-leave-title');document.body.append(dialog);dialog.addEventListener('close',()=>requestAnimationFrame(()=>document.querySelector('.research-leave-tile .tile-edit')?.focus({preventScroll:true})));}
 dialog.replaceChildren();dialog.append(Object.assign(el('h2','Scheduled break'),{id:'research-leave-title'}),el('p','Plan a holiday or another pause. The complete break must fit within the project dates.','help'));
 const fields=el('div',undefined,'fields'),s=schedule[row.id],t=timing(row),years=researchLeaveYears(row),existing=t.breaks?.[0]?.start;
 const fallback=t.start+Math.floor((t.end-t.start)/DAY/2)*DAY,chosen=existing??fallback;
 const weeks=numberInput('leave-edit-weeks',s.leaveWeeks+s.pauseWeeks,1),year=selectInput('leave-edit-year',years.map(y=>[y,'Year '+y]),academicYearOf(iso(chosen))),start=relativeInput('leave-edit-start',iso(chosen));weeks.min=0;weeks.max=8;
 field(fields,'Number of weeks',weeks);field(fields,'Academic year',year);field(fields,'Scheduled break begins (DD-MM)',start);year.disabled=years.length===1;
 dialog.append(fields);if(year.disabled)dialog.append(el('p','This project falls within one academic year, so the leave year is fixed.','help'));
 const range=el('p','Project dates: '+formatProjectDate(t.start)+' - Year '+academicYearOf(iso(t.start))+' to '+formatProjectDate(t.end-1)+' - Year '+academicYearOf(iso(t.end-1))+'. The end date recalculates when the leave duration changes.','help');dialog.append(range);
 const error=el('p',undefined,'leave-edit-error');error.id='leave-edit-error';error.setAttribute('role','alert');dialog.append(error);
 const actions=el('div',undefined,'dialog-actions'),cancel=el('button','Cancel'),save=el('button','Apply scheduled break','primary');cancel.type=save.type='button';cancel.onclick=()=>dialog.close();save.id='leave-edit-apply';save.onclick=()=>{const result=researchLeaveProposal(row,weeks.value,year.value,start.value);if(result.error){error.textContent=result.error;return;}if(validChange(row,result.updates))dialog.close();};actions.append(cancel,save);dialog.append(actions);
 const sync=()=>{start.disabled=Number(weeks.value)===0;start.required=Number(weeks.value)>0;error.textContent='';};weeks.addEventListener('input',sync);sync();dialog.showModal();weeks.focus();
}
function equalizeCourseTiles(){
 const drawer=document.getElementById('details-drawer');if(!drawer.open)return;
 const tiles=[...document.querySelectorAll('#inspector .information-tile,#inspector .duration-box>div')];
 for(const tile of tiles)tile.style.minHeight='';
}

function boundField(path,label,options=null,type='text',help=''){
 const value=path.split('.').reduce((o,k)=>o?.[k],p)??'',id='approval-'+path.replaceAll('.','-');
 const required=label.endsWith('*')?' required aria-required="true"':'';
 const control=options?`<select id="${id}" data-approval-bind="${escapeHTML(path)}"${required}>${options.map(([v,label])=>`<option value="${escapeHTML(v)}" ${String(v)===String(value)?'selected':''}>${escapeHTML(label)}</option>`).join('')}</select>`:type==='textarea'?`<textarea id="${id}" data-approval-bind="${escapeHTML(path)}"${required} maxlength="10000">${escapeHTML(value)}</textarea>`:`<input id="${id}" data-approval-bind="${escapeHTML(path)}"${required} type="${type}" value="${escapeHTML(value)}" maxlength="500">`;
 return `<div class="field ${type==='textarea'?'full':''}"><label for="${id}">${escapeHTML(label)}</label>${control}${help?`<p class="help">${escapeHTML(help)}</p>`:''}</div>`;
}
function approvalFieldMarkup(){
 if(approvalStage===0)return `<h3>Personal details and previous education</h3><p class="help">Your curriculum settings are taken from Build. Complete the details needed for the approval document.</p><div class="fields approval-fields">${boundField('student.firstName','First name *')}${boundField('student.lastName','Last name *')}${boundField('student.number','Student number *')}${p.student.education!=='VU_FW'?boundField('student.education','Previous education *',[['WO','Other university bachelor'],['HBO','HBO / university of applied sciences diploma']]):'<p class="full">Previous education: VU bachelor Farmaceutische Wetenschappen</p>'}${boundField('student.institution','Previous institution *')}${boundField('student.degree','Previous degree *')}${boundField('student.graduated','Graduation date *',null,'date')}</div>`;
 if(approvalStage===1){let html='<h3>Project and course information</h3><p class="help">Complete the host and topic for each selected project. You may mark a topic as not yet known.</p>';if(p.student.path==='SMC'&&rows().some(r=>r.id==='MAJOR')&&!p.major.smcPreparationAcknowledged)html+='<div class="approval-reminder"><strong>Research project preparation reminder</strong><p>For a Synthetic Radiopharmaceutical Chemistry internship, Advanced Radiopharmaceutical Chemistry is required preparation. Discuss this with the internship coordinator.</p><button id="acknowledge-smc" type="button">Acknowledge</button></div>';
  for(const [key,title,included]of [['major','Major research project',approvalRows().some(r=>r.id==='MAJOR'||r.id==='XM_0200')],['minor','Minor research project',approvalState().minor.enabled],['literature','Literature thesis',approvalState().literature.enabled]])if(included){html+=`<fieldset id="approval-project-${key}"><legend>${title}</legend>${key==='major'?`<p class="help">Registration: ${isEducation()?'30 EC Education major (XM_0200)':schedule.MAJOR?.year===1?'Part I + Part II, following the Year 1 start':'Single 48 EC variant, following the Year 2 start'}. Change selection and timing in Build.</p>`:''}<div class="fields">${boundField(key+'.hostStatus','Host status *',[['','Choose a status...'],['proposed','Proposed'],['confirmed','Confirmed']])}${boundField(key+'.host','Host / institution *')}${boundField(key+'.topicStatus','Topic status *',[['','Choose a status...'],['unknown','Not yet known'],['proposed','Proposed'],['confirmed','Confirmed']])}${p[key].topicStatus!=='unknown'?boundField(key+'.topic','Topic *',null,'textarea'):''}</div></fieldset>`;}
  for(const c of approvalState().custom){html+=`<fieldset id="approval-custom-${escapeHTML(c.uid)}"><legend>${escapeHTML(c.name)}</legend><p class="help">Unlisted course. Its suitability and classification require review.</p><div class="fields">${boundField('custom.'+p.custom.indexOf(c)+'.institution','Institution *')}${boundField('custom.'+p.custom.indexOf(c)+'.level','Academic level *',[['','Choose a level...'],['400','400'],['500','500'],['600','600']])}${boundField('custom.'+p.custom.indexOf(c)+'.url','Public course-information link *',null,'url')}</div></fieldset>`;}

  if(!html.includes('<fieldset'))html+='<p>No project or unlisted-course details to complete.</p>';html+='<details class="outside-details"><summary>Entry and supervision information</summary><p class="help">At least 18 EC must be obtained from the programme before starting a major or minor research project or literature thesis (TER Article 8.1). Major Part I must be passed before Part II. Eligibility, supervision and project arrangements are checked through the existing internship process.</p>'+(isEducation()?'<p class="help">Education is taught in English in Year 1 and Dutch in Year 2. Dutch-language admission requirements apply.</p>':'')+(p.literature.enabled?'<p class="help">The literature thesis is independent of the research project and must have a different topic.</p>':'')+'</details>';return html;
 }
 return `<h3>Review your Personal Education Plan</h3><p class="help">Resolve the items below or request an exception where offered. Review items remain visible in the PDF for the relevant reviewer.</p>${boundField('notes','Additional explanation (optional)',null,'textarea')}<p>Specialisation coordinator: <strong>${escapeHTML(A.coordinatorName(approvalState()))}</strong></p><p class="help">After downloading the PDF, send it to your specialisation coordinator for completion and preapproval. Then follow the Examination Board submission procedure. Generating a PDF does not grant approval.</p>`;
}
var setupWasReady=false;
function renderSetupSummary(){
 const config=document.querySelector('.configuration');let wrap=document.getElementById('setup-summary');
 if(!wrap){wrap=el('details',undefined,'setup-summary');wrap.id='setup-summary';const summary=el('summary');summary.id='setup-summary-label';config.before(wrap);wrap.append(summary,config);}
 const ready=configurationReady()&&viewChosen()&&disclaimerAcknowledged;
 wrap.hidden=activeStep==='approval';wrap.classList.toggle('setup-complete',ready);
 if(!ready)wrap.open=true;else if(!setupWasReady)wrap.open=false;
 document.getElementById('setup-summary-label').textContent='Your background information: '+(DATA.names[p.student.specialization]||p.student.specialization)+(p.student.path?' / '+p.student.path:'')+' - Cohort 2026 [Click to change]';
 setupWasReady=ready;
}
function renderForwardAction(){
 const button=document.getElementById('export-pep'),total=plannerResult().total;
 const ready=configurationReady()&&viewChosen()&&(disclaimerAcknowledged||tourRunning),canEnter=ready&&total>=120;
 let label,description,disabled=tourRunning;
 if(activeStep==='build'){
  label='Continue to Approval';disabled=disabled||!canEnter;
  description=!ready?'Complete setup to start building.':total<120?'Add '+R.round(120-total)+' EC to continue.':'Course selection ready. Complete your approval details next.';
 }else{
  const result=approvalEvaluation();
  label=approvalStage===0?'Continue to project details':approvalStage===1?'Continue to final review':'Download approval PDF';
  disabled=disabled||(approvalStage===2&&!result.canExport);
  description=approvalStage<2?'Approval - '+(approvalStage+1)+' of 3':result.canExport?'Ready to download and send for approval.':result.errors.length+' requirement'+(result.errors.length===1?'':'s')+' still to complete. Review below.';
 }
 button.querySelector('.button-label').textContent=label;
 button.querySelector('svg').outerHTML=processIcon(activeStep==='approval'&&approvalStage===2?'review':'approval');
 button.disabled=disabled;button.classList.add('primary');button.classList.remove('export-ready');
 button.title=description;button.removeAttribute('aria-describedby');
 document.getElementById('export-pdf').querySelector('.button-label').textContent='Export planning overview';
}
function forwardProcess(){
 if(tourRunning)return;
 if(activeStep==='build')setStep('approval');else if(approvalStage<2)goApprovalStage(approvalStage+1);else downloadApprovalPDF();
}
function approvalPlanningWarnings(){
 const curriculumNotices=new Set(['Major research project required','Admissions Board approval needed','Mandatory course removed','Unlisted course - confirmation needed']);
 return integratedWarnings().filter(w=>!w.approvalIssue&&!curriculumNotices.has(w.title));
}

let approvalNavigationFrame=false;
function queueApprovalNavigationVisibility(){if(approvalNavigationFrame)return;approvalNavigationFrame=true;requestAnimationFrame(()=>{approvalNavigationFrame=false;updateApprovalNavigationVisibility();});}
function updateApprovalNavigationVisibility(){
 const top=approvalRoot.querySelector('[data-approval-navigation="top"]'),bottom=approvalRoot.querySelector('[data-approval-navigation="bottom"]');
 if(!top||!bottom||activeStep!=='approval')return;
 let coveredTop=0;
 for(const selector of ['.head-actions','.process-timeline']){const node=document.querySelector(selector),rect=node.getBoundingClientRect(),position=getComputedStyle(node).position;if((position==='sticky'||position==='fixed')&&rect.top<=coveredTop+1&&rect.bottom>0)coveredTop=Math.max(coveredTop,rect.bottom);}
 const rect=top.getBoundingClientRect(),scrollNeeded=document.documentElement.scrollHeight>innerHeight+1;
 const show=scrollNeeded&&rect.bottom<=coveredTop+1;
 if(!show&&bottom.contains(document.activeElement)){const selector=document.activeElement.hasAttribute('data-next-approval-section')?'[data-next-approval-section]':'[data-previous-approval-section]';top.querySelector(selector)?.focus({preventScroll:true});}
 bottom.hidden=!show;
}
function approvalSectionNextMarkup(position='top'){
 const previous=approvalStage===0?'Build':approvalStages[approvalStage-1];
 return '<div class="approval-section-next" data-approval-navigation="'+position+'"'+(position==='bottom'?' hidden':'')+'><button type="button" data-previous-approval-section><span aria-hidden="true">←</span> Previous: '+previous+'</button>'+(approvalStage<2?'<button type="button" class="primary" data-next-approval-section>Next: '+approvalStages[approvalStage+1]+' <span aria-hidden="true">→</span></button>':'')+'</div>';
}
function renderApproval(){
 sectionNavigation.remove();const value=approvalEvaluation(),final=approvalStage===2;
 approvalRoot.innerHTML=`<div class="approval-content"><div class="approval-heading"><div><h2 id="approval-title" tabindex="-1">${approvalStages[approvalStage]}</h2><p>${final?'Review your curriculum and remaining requirements, then download the approval PDF.':'Complete this section, then continue to the next.'}</p></div></div><div class="approval-context"><span><strong>Specialisation</strong> ${escapeHTML(DATA.names[p.student.specialization]||p.student.specialization)}</span>${p.student.path?`<span><strong>Path</strong> ${escapeHTML(DATA.paths[p.student.path]||p.student.path)}</span>`:''}<span><strong>Cohort</strong> 2026</span></div><section class="approval-entry" id="approval-entry">${approvalSectionNextMarkup()}${approvalFieldMarkup()}${approvalSectionNextMarkup('bottom')}</section><section class="approval-requirements"><h3>${final?'Requirements to review':'Items for this section'}</h3><div id="approval-issues" class="approval-issues"></div></section><details class="approval-curriculum" ${final?'open':''}><summary>Selected curriculum - ${value.total} EC</summary><p class="help">Use the edit buttons to adjust course settings here. Changes also appear in Build. Your approval information is retained.</p><div id="approval-course-list"></div></details><div class="approval-planning"><h3>Planning advice</h3><p class="help">These timing warnings do not block the approval PDF.</p><div id="approval-planning-warnings"></div></div></div>`;mountSectionNavigation();
 document.getElementById('approval-course-list').append(unifiedCourseList(true));renderApprovalIssues();
 approvalRoot.querySelectorAll('[data-next-approval-section]').forEach(button=>button.onclick=()=>goApprovalStage(approvalStage+1));
 approvalRoot.querySelectorAll('[data-previous-approval-section]').forEach(button=>button.onclick=()=>approvalStage===0?setStep('build'):goApprovalStage(approvalStage-1));
 const smc=document.getElementById('acknowledge-smc');if(smc)smc.onclick=()=>{p.major.smcPreparationAcknowledged=true;commitState();renderApproval();};
 if(detailsApprovalReturn)document.querySelector('.approval-curriculum').open=detailsApprovalReturn.curriculumOpen;
 const planning=approvalPlanningWarnings();document.querySelector('.approval-planning').hidden=!final||!planning.length;document.getElementById('approval-planning-warnings').replaceChildren(...planning.map(w=>warningElement(w)));addCalendarGuidance(document.getElementById('approval-planning-warnings'),planning);queueApprovalNavigationVisibility();
 renderForwardAction();
}
function renderApprovalIssues(){
 const result=approvalEvaluation(),box=document.getElementById('approval-issues');if(!box)return;box.replaceChildren();
 const visible=result.issues.filter(issue=>approvalStage===2||(approvalStage===0?issue.section==='personal':issue.section==='projects'||issue.id.startsWith('custom_')||issue.id.startsWith('outside')));
 document.querySelector('.approval-requirements').hidden=!visible.length;
 for(const issue of visible){const card=el('div',undefined,'approval-issue '+issue.severity);card.dataset.issueId=issue.id;const jump=el('button',issue.message,'issue-jump');jump.type='button';jump.addEventListener('click',()=>focusIssue(issue));card.append(jump);if(issue.id==='over120'){const mark=el('button','Mark extracurricular courses in Build','exception-button');mark.type='button';mark.onclick=openExtracurricularSelection;card.append(mark);}if(issue.requested)card.append(el('p','Exception request - decision pending: '+issue.reason,'help'));if(issue.exceptionable){const b=el('button',issue.requested?'Edit exception request':'Request an exception','exception-button');b.type='button';b.onclick=()=>requestApprovalException(issue);card.append(b);}styleWarningPanel(card,issue.requested?'Exception request':issue.id.endsWith('_review')?'Unlisted course':'Curriculum check',issue.severity==='error'?'requirement':'decision');box.append(card);}
 approvalRoot.querySelectorAll('[data-approval-bind]').forEach(control=>{const path=control.dataset.approvalBind,problem=result.errors.some(i=>i.id==='student_'+path.split('.')[1]||i.id===path.replace('.','_')||i.id===path.replace('.','_').replace('Status','_status'));control.setAttribute('aria-invalid',String(problem));});
 const b=document.getElementById('approval-download');if(b){b.disabled=tourRunning||!result.canExport;b.title=result.canExport?'Download the approval PDF with signature fields':'Resolve '+result.errors.length+' remaining requirement(s), or request a permitted exception.';}
 updateReviewStatus();
 renderForwardAction();
}
function focusIssue(issue){
 if(issue.id==='over120'){openExtracurricularSelection();return;}
 if(issue.id==='major_route'){setStep('build');openCatalogCategory('major');if(mobileQuery.matches)document.getElementById('course-drawer').showModal();return;}
 if(issue.section==='personal'){goApprovalStage(0);const field=issue.id==='graduated_format'?'approval-student-graduated':issue.id.startsWith('student_')?'approval-student-'+issue.id.slice(8):'approval-student-education';focusField(field);return;}
 if(issue.section==='projects'||issue.id.startsWith('custom_')||issue.id.startsWith('outside')){goApprovalStage(1);let target='approval-entry';for(const k of ['major','minor','literature'])if(issue.id.startsWith(k+'_'))target='approval-'+k+'-'+issue.id.slice(k.length+1).replace('_status','Status');const custom=p.custom.find(c=>issue.id.startsWith('custom_'+c.uid));if(custom)target='approval-custom-'+custom.uid;focusField(target);return;}
 if(issue.exceptionable){requestApprovalException(issue);return;}
 if(issue.id==='principles_decision'){goApprovalStage(2);document.getElementById('approval-entry').scrollIntoView({block:'center'});return;}
 setStep('build');message(issue.message,'warning');document.querySelector('.checks').scrollIntoView({block:'center'});
}
function focusField(id){const target=document.getElementById(id)||document.getElementById('approval-entry');target.scrollIntoView({block:'center'});target.focus?.({preventScroll:true});target.classList.add('attention-target');setTimeout(()=>target.classList.remove('attention-target'),1800);}
function focusApprovalCourse(row){if(row.custom||row.project||isResearch(row)||row.id==='XM_0198'){goApprovalStage(1);const key=isResearch(row)?row.id==='MINOR'?'minor':'major':'literature';focusField(row.custom?'approval-custom-'+row.id:'approval-project-'+key);}else{selectCourse(row.id);}}
function requestApprovalException(issue){const dialog=document.getElementById('approval-exception-dialog'),form=document.getElementById('approval-exception-form'),existing=p.exceptions[issue.exceptionId||issue.id]||{};document.getElementById('approval-exception-description').textContent=issue.message;form.elements.reason.value=existing.reason||'';form.elements.reference.value=existing.reference||'';dialog.showModal();form.elements.reason.oninput=()=>form.elements.reason.setCustomValidity('');form.onsubmit=e=>{e.preventDefault();if(!form.reportValidity())return;if(!form.elements.reason.value.trim()){form.elements.reason.setCustomValidity('Enter a justification for this request.');form.elements.reason.reportValidity();return;}p.exceptions[issue.exceptionId||issue.id]={reason:form.elements.reason.value.trim(),reference:form.elements.reference.value.trim(),selectionFingerprint:compositionFingerprint()};dialog.close();render();};document.getElementById('approval-exception-remove').hidden=!existing.reason;document.getElementById('approval-exception-remove').onclick=()=>{delete p.exceptions[issue.exceptionId||issue.id];dialog.close();render();};}
async function downloadApprovalPDF(){
 if(tourRunning)return;
 try{DDSValidation.validate(JSON.parse(stateSnapshot()),A);for(const row of rows()){const problem=scheduleProblem(row,schedule[row.id]);if(problem)throw Error(problem);if(isResearch(row)&&schedule[row.id].leaveWeeks+schedule[row.id].pauseWeeks>0){const s=schedule[row.id],t=timing(row),start=ms(s.breakStart);if(!Number.isFinite(start)||start<t.start||start+(s.leaveWeeks+s.pauseWeeks)*7*DAY>t.end)throw Error('The scheduled break must fit inside the project dates.');}}}catch(error){message('Action required: '+error.message,'error');return;}
 const snapshot=approvalState(),result=approvalEvaluation();if(!result.canExport){message('Resolve the remaining requirements or request an exception where permitted.','warning');renderApprovalIssues();return;}
 const buttons=[document.getElementById('export-pep')];buttons.forEach(b=>{if(b)b.disabled=true;});message('Preparing your approval PDF...');
 try{const logo=document.querySelector('.header img').src,documentRoot=window.IntegratedApprovalDocument.create(snapshot,logo),bytes=await window.PEP_PDF.create(documentRoot,snapshot,logo);downloadFile('Personal_Education_Plan_Approval.pdf',bytes,'application/pdf');document.getElementById('download-complete-dialog').showModal();}catch(error){message('Approval PDF could not be generated: '+error.message,'error');}finally{renderApprovalIssues();}
}
function exportIntegratedBuild(){return {kind:'DDS-integrated-pep',schemaVersion:1,appVersion:INTEGRATED_VERSION,approvalVersion:A.DATA.appVersion,ruleVersion:A.DATA.ruleVersion,savedAt:new Date().toISOString(),state:JSON.parse(stateSnapshot())};}
function validateIntegratedFile(file){
 if(file?.kind!=='DDS-integrated-pep'||file.schemaVersion!==1)throw Error('Open a build saved by this integrated version of Personal Education Plan.');
 if(Object.keys(file).some(k=>!['kind','schemaVersion','appVersion','approvalVersion','ruleVersion','savedAt','state'].includes(k)))throw Error('Unsupported saved-build metadata.');
 for(const key of ['appVersion','approvalVersion','ruleVersion','savedAt'])if(typeof file[key]!=='string'||file[key].length>200)throw Error('Invalid saved-build metadata: '+key);if(!Number.isFinite(Date.parse(file.savedAt)))throw Error('Invalid saved date.');
 if(file.ruleVersion!==A.DATA.ruleVersion)throw Error('This file uses a different cohort rule version.');
 const v=file.state;DDSValidation.validate(v,A);if(!v||typeof v!=='object'||Array.isArray(v)||!v.p||!v.schedule||!Array.isArray(v.excluded)||!v.customPeriods)throw Error('This build file is incomplete.');
 if(!['build','approval'].includes(v.activeStep)||!['','calendar','list'].includes(v.buildView)||![0,1,2].includes(v.approvalStage))throw Error('Invalid saved view or step.');
 if(!v.p.student||!Array.isArray(v.p.custom)||!v.p.exceptions||!v.p.courseDetails)throw Error('Missing approval information.');
 return v;
}
async function openIntegratedFile(file){if(!file)return;try{if(file.size>5000000)throw Error('The build file is too large.');const v=validateIntegratedFile(JSON.parse(await file.text()));const prior=stateSnapshot();
 // Validate the full replacement before showing the confirmation or touching the current build.
 try{restoreState(JSON.stringify(v));validateCurrentSchedule(false);approvalEvaluation();}catch(error){restoreState(prior);throw error;}restoreState(prior);
 if(configurationReady()&&!await confirmReplacement('Open this build?','Replace both Build and Approval with the saved file? You can recover your current plan with Undo.'))return;
 for(const request of Object.values(v.p.exceptions))request.selectionFingerprint='';v.p.coordinator=A.coordinatorName(v.p);
 restoreState(JSON.stringify(v));resetCourseWarningPopups();render();syncResponsive();const checks=approvalEvaluation();message('Build imported and all checks recalculated. '+checks.errors.length+' action(s) required.'+(Object.keys(v.p.exceptions).length?' Reconfirm imported exception justifications before export; decisions remain pending.':''));
 }catch(error){message(error.message,'error');}finally{document.getElementById('open-file').value='';}}
function approvalInput(e){const control=e.target,path=control.dataset.approvalBind;if(!path)return;const parts=path.split('.');let target=p;for(const key of parts.slice(0,-1))target=target[key]??=(/^\d+$/.test(key)?[]:{});target[parts.at(-1)]=control.value.replace(/\u2014/g,'-');
 if(path==='student.education'){document.getElementById('education').value=p.student.education;}commitState();renderApprovalIssues();
 if(e.type==='change'&&(path.endsWith('Status')||path==='student.education'))renderApproval();
}
approvalRoot.addEventListener('input',approvalInput);approvalRoot.addEventListener('change',approvalInput);
document.getElementById('download-complete-close').onclick=()=>document.getElementById('download-complete-dialog').close();
document.getElementById('step-approval').addEventListener('animationend',e=>{if(e.animationName==='approval-unlock-pulse')e.currentTarget.classList.remove('approval-just-unlocked');});
document.getElementById('step-build').onclick=()=>setStep('build');document.getElementById('step-approval').onclick=()=>setStep('approval');
document.getElementById('approval-exception-cancel').onclick=()=>document.getElementById('approval-exception-dialog').close();
document.getElementById('action-warning-keep').onclick=()=>closeActionWarning('keep');document.getElementById('action-warning-adjust').onclick=()=>closeActionWarning(removedPrinciplesInBatch(warningBatch)?'cancel':'adjust');document.getElementById('operation-error-close').onclick=()=>document.getElementById('operation-error-dialog').close();
document.querySelectorAll('[data-build-view]').forEach(button=>button.onclick=()=>{buildView=button.dataset.buildView;render();});
// Public deterministic hooks used by local regression checks.
document.getElementById('skip-task').onclick=e=>{e.preventDefault();focusTaskHeading();const target=document.activeElement;target.scrollIntoView({block:'start'});};
document.querySelector('#category-legend>summary').onclick=e=>{if(mobileQuery.matches){e.preventDefault();categoryLegendExpanded=!categoryLegendExpanded;syncReviewNavigation();}};
addEventListener('scroll',queueApprovalNavigationVisibility,{passive:true});
addEventListener('resize',queueApprovalNavigationVisibility);
new ResizeObserver(queueApprovalNavigationVisibility).observe(approvalRoot);
new ResizeObserver(fitHeaderTitle).observe(document.querySelector('.header-title'));
if(document.fonts?.ready)document.fonts.ready.then(fitHeaderTitle);
window.PEP_INTEGRATED={researchLeaveProposal,researchLeaveYears,openResearchLeave,updateApprovalNavigationVisibility,canMarkExtracurricular,isExtracurricular,setExtracurricular,approvalRows,openExtracurricularSelection,hasFlexiblePlacement,automaticCourseYear,placementWarnings,timingLines,queueActionWarnings,showActionWarnings,closeActionWarning,compositionFingerprint,version:INTEGRATED_VERSION,getState:()=>JSON.parse(stateSnapshot()),load:v=>{restoreState(JSON.stringify(v));resetCourseWarningPopups();render();syncResponsive();},approvalState,approvalEvaluation,exportBuild:exportIntegratedBuild,validateFile:validateIntegratedFile,setStep,goApprovalStage,forwardProcess,setView:view=>{buildView=view;render();},proposePlacement,renderList:unifiedCourseList,document:()=>window.IntegratedApprovalDocument.create(approvalState(),document.querySelector('.header img').src),downloadApprovalPDF};

// Respond to the space left by the catalogue as well as to the browser viewport.
let smallCalendarLayoutKey='';
new ResizeObserver(()=>{const key=useSmallYearCalendar()+':'+smallCalendarNameSize();if(key!==smallCalendarLayoutKey){smallCalendarLayoutKey=key;renderTimeline();}}).observe(document.querySelector('.centre'));
