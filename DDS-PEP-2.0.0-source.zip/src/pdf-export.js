/* Vector landscape PDF: canvas, workload, applicable warnings, curriculum checks and categorised course tables. */
(function(root){'use strict';
async function create(model,fontData){
 const {PDFDocument,StandardFonts,rgb}=root.PDFLib;
 const doc=await PDFDocument.create();doc.registerFontkit(root.fontkit);
 const font=await doc.embedFont(Uint8Array.from(atob(fontData),c=>c.charCodeAt(0)),{subset:true});
 const supported=new Set(font.getCharacterSet());
 const W=1190.55,H=841.89,M=36,width=W-M*2,navy=rgb(.094,.231,.322),muted=rgb(.32,.43,.5),line=rgb(.84,.89,.92),white=rgb(1,1,1);
 const hex=h=>rgb(...[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255));
 const clean=s=>String(s??'').replace(/[–-−]/g,'-').replace(/→/g,' (continues)').replace(/←/g,'(continued) ').replace(/\r/g,'');
 const measure=(s,size)=>font.widthOfTextAtSize(s,size);
 function wrap(value,size,max){const text=clean(value);for(const ch of text)if(ch!=='\n'&&!supported.has(ch.codePointAt(0)))throw Error('The PDF font does not support "'+ch+'". Replace this character in the course name or note.');const lines=[];for(const paragraph of text.split('\n')){let current='';for(const word of paragraph.split(/\s+/)){if(!word)continue;const test=current?current+' '+word:word;if(measure(test,size)<=max){current=test;continue;}if(current){lines.push(current);current='';}let part='';for(const char of word){if(part&&measure(part+char,size)>max){lines.push(part);part='';}part+=char;}current=part;}lines.push(current);}return lines;}
 function text(page,value,x,top,size=11,color=navy){page.drawText(clean(value),{x,y:H-top-size,size,font,color});}
 function rect(page,x,top,w,h,color,border=null){page.drawRectangle({x,y:H-top-h,width:w,height:h,color,borderColor:border||undefined,borderWidth:border ? .6 : 0});}
 function rule(page,x,top,x2,top2,color=line){page.drawLine({start:{x,y:H-top},end:{x:x2,y:H-top2},thickness:.6,color});}
 const generatedLabel='Generated on '+new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'long',year:'numeric',timeZone:'Europe/Amsterdam'}).format(new Date());
 function header(page,title){text(page,generatedLabel,W-M-measure(generatedLabel,10),29,10,muted);text(page,'Personal Education Plan',M,25,20);text(page,title,M,56,15);text(page,model.settings,M,78,11,muted);}
 function footer(page){text(page,'Version '+model.version,M,H-27,9,muted);}
 const usedCats=[...new Set(model.years.flatMap(y=>y.rows.flatMap(r=>r.blocks.map(b=>b.category==='minor'?'major':b.category==='educationElective'?'educationCore':b.category))))];
 const noticeLines=model.disclaimer?wrap(model.disclaimer,10.5,width-28):[],noticeHeight=noticeLines.length?noticeLines.length*14+37:0;let noticeDrawn=false;
 function categoryLegend(page,top){if(!noticeDrawn&&noticeHeight){rect(page,M,top,width,noticeHeight-8,hex('#fff0ef'));rect(page,M,top,4,noticeHeight-8,hex('#cf4843'));text(page,'Important information',M+14,top+7,11,hex('#a52d28'));noticeLines.forEach((value,i)=>text(page,value,M+14,top+25+i*14,10.5,hex('#852b27')));top+=noticeHeight;noticeDrawn=true;}let x=M;for(const cat of usedCats){const label=model.categories[cat].short,w=measure(label,10)+32;if(x>M&&x+w>M+width){x=M;top+=20;}rect(page,x,top+3,8,8,hex(model.colors[cat][0]));text(page,label,x+13,top,10,muted);x+=w;}return top+25;}
 function axis(page,top,bottom){const total=365;let offset=0;for(const month of model.months){const x=M+offset/total*width,w=month.days/total*width;if(month.summer)rect(page,x,top,w,bottom-top,hex('#fff7eb'));rect(page,x,top+20,w,22,hex('#f7fafc'));text(page,month.label,x+(w-measure(month.label,11))/2,top+24,11,muted);rule(page,x,top,x,bottom);offset+=month.days;}rule(page,M+width,top,M+width,bottom);for(const p of model.periods){const x=M+p.offset/365*width,w=p.days/365*width;rect(page,x,top,w,20,hex(p.label==='Summer'?'#fff0dc':'#eaf3f8'));text(page,p.label,x+(w-measure(p.label,10))/2,top+4,10);}rule(page,M,top+42,M+width,top+42);}
 function workload(page,year,top,compact=false){text(page,'Workload or overlap issues',M,top,13);top+=compact?20:24;const cellHeight=year.workload.some(c=>c.secondaryStatus)?(compact?28:34):(compact?20:26);for(const cell of year.workload){const x=M+cell.offset/365*width,w=cell.days/365*width,color=cell.severity==='high'?'#fde9e7':cell.severity==='overlap'?'#fde9e7':cell.severity==='ok'?'#edf7ee':'#f6f9fb';rect(page,x,top,w,cellHeight,hex(color),line);text(page,cell.label,x+(w-measure(cell.label,10))/2,top+2,8,muted);if(cell.secondaryStatus){text(page,'Overlap',x+(w-measure('Overlap',9))/2,top+(compact?20:25),8,hex('#a52d28'));}if(cell.status){const parts=wrap(cell.status,8,w-8);parts.forEach((t,i)=>text(page,t,x+(w-measure(t,8))/2,top+(compact?10:13)+i*9,8,hex(cell.severity==='high'?'#a52d28':cell.severity==='overlap'?'#a52d28':'#246436')));}}text(page,'Year total: '+year.total+' EC of 60 EC'+(year.extraEC?' · '+year.extraEC+' EC extracurricular':''),M,top+cellHeight+10,12);text(page,'Hatched segments = leave / pause',M+width-220,top+cellHeight+12,10,muted);return top+cellHeight+(compact?24:33);}
 const compactYears=model.years.map(year=>({...year,layouts:year.rows.map(row=>({...row,height:Math.max(38,...row.blocks.map(b=>wrap(b.name,11,b.width/365*width-14).length*14+14))}))}));
 let legendRows=1,legendWidth=0;for(const cat of usedCats){const w=measure(model.categories[cat].short,10)+32;if(legendWidth&&legendWidth+w>width){legendRows++;legendWidth=0;}legendWidth+=w;}
 const overviewHeight=128+noticeHeight+(legendRows-1)*20+compactYears.reduce((sum,year)=>sum+22+42+year.layouts.reduce((n,r)=>n+r.height,0)+8+20+(year.workload.some(c=>c.secondaryStatus)?28:20)+24+8,0);
 const combined=overviewHeight<=H-42;
 let warningPage=null,warningTop=0;
 if(combined){const page=doc.addPage([W,H]);header(page,'Two-year curriculum overview');let top=categoryLegend(page,103);for(const year of compactYears){text(page,'Year '+year.year,M,top,14);top+=22;const bottom=top+42+year.layouts.reduce((n,r)=>n+r.height,0);axis(page,top,bottom);let rowTop=top+42;for(const row of year.layouts){rule(page,M,rowTop+row.height,M+width,rowTop+row.height);for(const b of row.blocks){const x=M+b.offset/365*width,w=b.width/365*width,[cat,soft,deep]=model.colors[b.category];rect(page,x+1,rowTop+4,w-2,row.height-8,hex(soft),hex(cat));rect(page,x+1,rowTop+4,3,row.height-8,hex(cat));for(const br of b.breaks){const bx=M+br.offset/365*width,bw=br.width/365*width;rect(page,bx,rowTop+4,bw,row.height-8,hex('#e3e8eb'));for(let h=0;h<bw;h+=8)rule(page,bx+h,rowTop+4,bx+Math.min(h+row.height-8,bw),rowTop+row.height-4,hex('#9ba9b2'));}wrap(b.name,11,w-14).forEach((t,i)=>text(page,t,x+8,rowTop+9+i*14,11,hex(deep)));}rowTop+=row.height;}top=workload(page,year,bottom+8,true)+8;}warningPage=page;warningTop=top;footer(page);}
 if(!combined) for(const year of model.years){
  const layouts=year.rows.map(row=>({...row,height:Math.max(52,...row.blocks.map(b=>wrap(b.name,11,b.width/365*width-14).length*14+16))}));
  let index=0,part=0;
  do{const page=doc.addPage([W,H]);part++;header(page,'Year '+year.year+(part>1?' - continued':''));let y=categoryLegend(page,103),axisTop=y;y+=42;const first=index;while(index<layouts.length&&y+layouts[index].height<=H-(year.workload.some(c=>c.secondaryStatus)?148:140)){y+=layouts[index].height;index++;}if(index===first&&index<layouts.length){throw Error('A course name is too long for the PDF overview. Shorten the name and try again.');}axis(page,axisTop,y);let rowTop=axisTop+42;for(const row of layouts.slice(first,index)){rule(page,M,rowTop+row.height,M+width,rowTop+row.height);for(const b of row.blocks){const x=M+b.offset/365*width,w=b.width/365*width,[cat,soft,deep]=model.colors[b.category];rect(page,x+1,rowTop+5,w-2,row.height-10,hex(soft),hex(cat));rect(page,x+1,rowTop+5,3,row.height-10,hex(cat));for(const br of b.breaks){const bx=M+br.offset/365*width,bw=br.width/365*width;rect(page,bx,rowTop+5,bw,row.height-10,hex('#e3e8eb'));for(let h=0;h<bw;h+=8)rule(page,bx+h,rowTop+5,bx+Math.min(h+row.height-10,bw),rowTop+row.height-5,hex('#9ba9b2'));}wrap(b.name,11,w-14).forEach((t,i)=>text(page,t,x+8,rowTop+11+i*14,11,hex(deep)));}rowTop+=row.height;}if(!layouts.length)text(page,'No courses scheduled.',M+12,y+12,12,muted);warningTop=workload(page,year,y+12)+16;warningPage=page;footer(page);}while(index<layouts.length);
 }
 if(model.warnings.length){
  const bottomLimit=H-45;let page=warningPage,y=warningTop;
  const newWarningPage=()=>{page=doc.addPage([W,H]);header(page,'Scheduling warnings - continued');y=105;footer(page);};
  const first=model.warnings[0],firstHeight=wrap(first.title,12,width-28).length*16+wrap(first.text,11,width-28).length*14+16,minimum=22+(firstHeight<=bottomLimit-105?firstHeight:wrap(first.title,12,width-28).length*16+14+16);
  if(!page||y+minimum>bottomLimit){page=doc.addPage([W,H]);header(page,'Scheduling warnings');y=105;footer(page);}else{text(page,'Scheduling warnings',M,y,14);y+=22;}
  for(const warning of model.warnings){const title=wrap(warning.title,12,width-28),body=wrap(warning.text,11,width-28);let offset=0;
   do{const fullHeight=title.length*16+(body.length-offset)*14+16;
    if(y+fullHeight>bottomLimit&&fullHeight<=bottomLimit-105)newWarningPage();
    let room=Math.floor((bottomLimit-y-title.length*16-16)/14);
    if(room<1){newWarningPage();room=Math.floor((bottomLimit-y-title.length*16-16)/14);}
    if(room<1)throw Error('A warning title is too long for the PDF overview.');
    const chunk=body.slice(offset,offset+room),height=title.length*16+chunk.length*14+16;
    rect(page,M,y,width,height,hex('#fff0ef'));rect(page,M,y,4,height,hex('#cf4843'));
    title.forEach((t,i)=>text(page,t,M+14,y+7+i*16,12,hex('#a52d28')));
    chunk.forEach((t,i)=>text(page,t,M+14,y+8+title.length*16+i*14,11,hex('#852b27')));
    offset+=chunk.length;y+=height+8;
   }while(offset<body.length);
  }
  warningPage=page;warningTop=y;
 }

 // Keep the on-screen requirement checks and their status in the exported overview.
 if(model.checks?.length){
  let page=warningPage,y=warningTop;const bottom=H-45;
  const nextPage=()=>{page=doc.addPage([W,H]);header(page,'Curriculum checks');y=105;footer(page);};
  const linesFor=check=>{const lines=wrap(check.label+(check.value?': '+check.value:''),11,width-145);if(check.courses?.length){if(check.missing)lines.push(check.missingLabel||'Missing path courses:');for(const course of check.courses)lines.push(...wrap('• '+course,11,width-160));}return lines;};
  if(!page||y+28+linesFor(model.checks[0]).length*14+16>bottom)nextPage();else{text(page,'Curriculum checks',M,y,14);y+=26;}
  for(const check of model.checks){const all=linesFor(check),met=check.status==='pass',color=hex(met?'#176832':'#ac302c');let offset=0;
   do{const fullHeight=(all.length-offset)*14+16;if(y+fullHeight>bottom&&fullHeight<=bottom-105)nextPage();let count=Math.min(all.length-offset,Math.floor((bottom-y-16)/14));if(count<1){nextPage();count=Math.min(all.length-offset,Math.floor((bottom-y-16)/14));}const height=count*14+16;
    rect(page,M,y,width,height,hex(met?'#edf7ee':'#fff0ef'),line);rect(page,M+10,y+9,14,14,color);
    if(met){rule(page,M+13,y+16,M+16,y+20,white);rule(page,M+16,y+20,M+22,y+12,white);}else{rule(page,M+13,y+12,M+21,y+20,white);rule(page,M+21,y+12,M+13,y+20,white);}
    all.slice(offset,offset+count).forEach((value,i)=>text(page,value,M+34,y+8+i*14,11,color));text(page,met?'Met':'Not met',M+width-90,y+9,11,color);y+=height+6;offset+=count;
   }while(offset<all.length);
  }
 }


 // Categorised course register follows the visual overview and warnings.
 if(model.courseGroups?.length){
  let page=null,y=0,pageSection='',currentSection='';const bottom=H-48,cols=[M,M+width*.51,M+width*.71,M+width];
  const newCoursePage=()=>{page=doc.addPage([W,H]);header(page,'Course list by category');y=108;pageSection='';footer(page);};
  const sectionHead=(label,continued=false)=>{rect(page,M,y,width,22,hex('#24566f'));text(page,label+(continued?' - continued':''),M+9,y+4,12,white);y+=26;pageSection=label;};
  const categoryHead=(label,continued=false)=>{rect(page,M,y,width,20,hex('#eaf3f8'));text(page,label+(continued?' - continued':''),M+9,y+5,11);y+=20;rect(page,M,y,width,18,hex('#f7fafc'));['Course name','Course code','Period(s)'].forEach((label,i)=>text(page,label,cols[i]+9,y+4,10,muted));y+=18;};
  newCoursePage();
  for(const group of model.courseGroups){const section=group.section||'Course list',first=group.courses[0],firstH=Math.max(...[first.name,first.code,first.period].map((value,i)=>wrap(value,10,cols[i+1]-cols[i]-18).length))*12+8;if(y+(pageSection===section?0:26)+38+Math.min(firstH,100)>bottom)newCoursePage();if(pageSection!==section)sectionHead(section,currentSection===section);currentSection=section;categoryHead(group.label);
   for(const course of group.courses){const values=[course.name,course.code,course.period],lines=values.map((value,i)=>wrap(value,10,cols[i+1]-cols[i]-18)),count=Math.max(...lines.map(ls=>ls.length));let offset=0;
    while(offset<count){let room=Math.floor((bottom-y-8)/12);if(room<1){newCoursePage();sectionHead(section,true);categoryHead(group.label,true);room=Math.floor((bottom-y-8)/12);}const chunk=Math.min(count-offset,room),height=chunk*12+8;rect(page,M,y,width,height,white,line);for(let i=1;i<3;i++)rule(page,cols[i],y,cols[i],y+height);for(let c=0;c<3;c++)lines[c].slice(offset,offset+chunk).forEach((value,j)=>text(page,value,cols[c]+9,y+4+j*12,10));y+=height;offset+=chunk;if(offset<count){newCoursePage();sectionHead(section,true);categoryHead(group.label,true);}}
   }y+=8;
  }
 }
 const pages=doc.getPages();pages.forEach((page,i)=>text(page,(i+1)+' / '+pages.length,W-M-40,H-27,9,muted));doc.setTitle('DDS curriculum overview');doc.setCreator('Personal Education Plan '+model.version);return doc.save();
}
root.DDSPlannerPDF={create};
})(typeof globalThis!=='undefined'?globalThis:this);
