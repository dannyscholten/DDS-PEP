window.PEP_DATA=JSON.parse(document.getElementById('catalogue').textContent);
