"""Build the standalone planner and GitHub Pages package from readable sources."""
from pathlib import Path
import base64, re, shutil
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'src'
for directory in ['outputs', 'work', 'outputs/github-pages']:
    (ROOT / directory).mkdir(parents=True, exist_ok=True)
text = (SRC / 'planner.template.html').read_text()
text = text.replace('@@PLANNER_CSS@@', (SRC / 'header-fonts.css').read_text() + (SRC / 'planner.css').read_text() + (SRC / 'integration.css').read_text())
text = text.replace('@@FONT@@', base64.b64encode((SRC / 'vendor/NotoSans-Regular.ttf').read_bytes()).decode())
def source_file(name):
    body = (SRC / name).read_text()
    if name == 'planner.js':
        body = body.replace('// @INTEGRATION_MODULE', (SRC / 'integration.js').read_text())
    return body.replace('</script', r'<\/script')
text = re.sub(r'@@([^@]+)@@', lambda m: source_file(m[1]), text)
(ROOT / 'outputs/Personal_Education_Plan_Local_2.0.0.html').write_text(text)
(ROOT / 'outputs/DDS_Curriculum_Planner.html').write_text(text)
(ROOT / 'outputs/PEP_Builder_Periods_Test.html').write_text(text)
# Local integrated review copies; publishing remains a separate explicit action.
(ROOT / 'outputs/PEP_Builder_Approval_Test.html').write_text(text)
(ROOT / 'work/planner-clear-canvas.html').write_text(text)
pages = ROOT / 'outputs/github-pages'
(pages / 'vendor').mkdir(exist_ok=True)
for name in ['pdf-lib.min.js', 'fontkit.min.js']:
    body = (SRC / 'vendor' / name).read_text().replace('</script', r'<\/script')
    text = text.replace('<script>' + body + '</script>', '<script src="vendor/' + name + '"></script>')
    shutil.copyfile(SRC / 'vendor' / name, pages / 'vendor' / name)
for name in ['pdf-lib.LICENSE.txt', 'fontkit.LICENSE.txt', 'NotoSans.LICENSE.txt', 'Manrope.LICENSE.txt', 'SourceSans3.LICENSE.txt', 'Urbanist.LICENSE.txt', 'DMSans.LICENSE.txt']:
    shutil.copyfile(SRC / 'vendor' / name, pages / 'vendor' / name)
font_script = 'window.DDS_PLANNER_FONT="' + base64.b64encode((SRC / 'vendor/NotoSans-Regular.ttf').read_bytes()).decode() + '";'
(pages / 'vendor/planner-font.js').write_text(font_script)
text = text.replace('<script>' + font_script + '</script>', '<script src="vendor/planner-font.js"></script>')
(pages / 'vendor/LICENSES.txt').write_text('\n\n'.join((SRC / 'vendor' / name).read_text() for name in ['pdf-lib.LICENSE.txt', 'fontkit.LICENSE.txt', 'NotoSans.LICENSE.txt', 'Manrope.LICENSE.txt', 'SourceSans3.LICENSE.txt', 'Urbanist.LICENSE.txt', 'DMSans.LICENSE.txt']))
(pages / 'index.html').write_text(text)
shutil.copyfile(SRC / 'scheduling-decisions.json', ROOT / 'outputs/DDS_Planner_Scheduling_Decisions_2026.json')
print('Built local Personal Education Plan 2.0.0 test. No publication performed.')
